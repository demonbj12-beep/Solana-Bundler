#!/bin/bash
# ============================================================
# NEXUS BUNDLER - Setup Script
# Run this once after importing to Replit
# ============================================================

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║         NEXUS BUNDLER SETUP              ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Create data directory
mkdir -p backend/data

# Copy .env if not exists
if [ ! -f backend/.env ]; then
  cp .env.example backend/.env
  
  # Auto-generate JWT secret
  JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")
  
  # Replace placeholder
  if [[ "$OSTYPE" == "darwin"* ]]; then
    sed -i '' "s/CHANGE_THIS_TO_A_RANDOM_SECRET_64_CHARS_MINIMUM/$JWT_SECRET/" backend/.env
  else
    sed -i "s/CHANGE_THIS_TO_A_RANDOM_SECRET_64_CHARS_MINIMUM/$JWT_SECRET/" backend/.env
  fi
  
  echo "✅ Created backend/.env with auto-generated JWT secret"
  echo ""
  echo "⚠️  IMPORTANT: Edit backend/.env and set:"
  echo "   - PLATFORM_FEE_WALLET (your Solana wallet address)"
  echo "   - SOLANA_RPC_URL (use Helius/Quicknode for production)"
  echo "   - BAGS_API_KEY (from bags.fm)"
  echo ""
else
  echo "✅ backend/.env already exists"
fi

# Install backend deps
echo "📦 Installing backend dependencies..."
cd backend && npm install
cd ..

# Install frontend deps
echo "📦 Installing frontend dependencies..."
cd frontend && npm install
cd ..

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║           SETUP COMPLETE! 🚀              ║"
echo "╠══════════════════════════════════════════╣"
echo "║                                          ║"
echo "║  To start in development:                ║"
echo "║    Backend:  cd backend && npm start     ║"
echo "║    Frontend: cd frontend && npm run dev  ║"
echo "║                                          ║"
echo "║  Edit backend/.env before launching!     ║"
echo "║                                          ║"
echo "╚══════════════════════════════════════════╝"
echo ""
