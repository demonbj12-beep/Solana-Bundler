const jwt = require('jsonwebtoken');
const { get } = require('../services/database');

const SECRET = process.env.JWT_SECRET || 'CHANGE_THIS_NOW';
const EXPIRY = process.env.JWT_EXPIRY || '24h';

function generateAccessToken(userId, email) {
  return jwt.sign({ userId, email, type: 'access' }, SECRET, { expiresIn: EXPIRY, algorithm: 'HS256' });
}

function generateRefreshToken(userId) {
  return jwt.sign({ userId, type: 'refresh' }, SECRET, { expiresIn: '30d', algorithm: 'HS256' });
}

function verifyToken(token) {
  return jwt.verify(token, SECRET, { algorithms: ['HS256'] });
}

async function requireAuth(req, res, next) {
  try {
    const auth = req.headers.authorization;
    if (!auth?.startsWith('Bearer ')) return res.status(401).json({ error: 'No token provided' });

    const token = auth.split(' ')[1];
    const decoded = verifyToken(token);
    if (decoded.type !== 'access') return res.status(401).json({ error: 'Invalid token type' });

    const user = await get('SELECT id, email, is_active, encryption_salt FROM users WHERE id = ?', [decoded.userId]);
    if (!user || !user.is_active) return res.status(401).json({ error: 'Unauthorized' });

    req.user = { id: user.id, email: user.email, encryptionSalt: user.encryption_salt };
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
    return res.status(401).json({ error: 'Invalid token' });
  }
}

module.exports = { generateAccessToken, generateRefreshToken, verifyToken, requireAuth };
