const fetch = require('node-fetch');
const FormData = require('form-data');
const { Keypair, VersionedTransaction, LAMPORTS_PER_SOL } = require('@solana/web3.js');
const bs58 = require('bs58');
const { getConnection } = require('./solana');

const PUMP_PORTAL = 'https://pumpportal.fun/api';
const JITO_ENDPOINTS = [
  'https://mainnet.block-engine.jito.wtf/api/v1/bundles',
  'https://amsterdam.mainnet.block-engine.jito.wtf/api/v1/bundles',
  'https://ny.mainnet.block-engine.jito.wtf/api/v1/bundles'
];

// ─── Metadata Upload ────────────────────────────────────────────────────────
async function uploadPumpFunMetadata(tokenData, imageBuffer) {
  const form = new FormData();
  form.append('name', tokenData.name);
  form.append('symbol', tokenData.symbol);
  form.append('description', tokenData.description || '');
  form.append('twitter', tokenData.twitter || '');
  form.append('telegram', tokenData.telegram || '');
  form.append('website', tokenData.website || '');
  form.append('showName', 'true');
  if (imageBuffer) {
    form.append('file', imageBuffer, { filename: 'token.png', contentType: 'image/png' });
  }

  const res = await fetch('https://pump.fun/api/ipfs', {
    method: 'POST', body: form, headers: form.getHeaders()
  });
  if (!res.ok) throw new Error(`IPFS upload failed: ${res.status}`);
  return res.json(); // { metadataUri }
}

// ─── Local Trade Tx ─────────────────────────────────────────────────────────
async function getLocalTx(payload) {
  const res = await fetch(`${PUMP_PORTAL}/trade-local`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`PumpPortal error: ${txt}`);
  }
  const buf = await res.arrayBuffer();
  return VersionedTransaction.deserialize(new Uint8Array(buf));
}

// ─── Jito Bundle Sender ─────────────────────────────────────────────────────
async function sendJitoBundle(encodedTxs) {
  const body = {
    jsonrpc: '2.0', id: 1,
    method: 'sendBundle',
    params: [encodedTxs]
  };

  for (const endpoint of JITO_ENDPOINTS) {
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.result) return { success: true, bundleId: data.result };
      }
    } catch (e) {
      console.warn(`Jito endpoint ${endpoint} failed:`, e.message);
    }
  }
  return { success: false };
}

// ─── Main Bundle Executor ───────────────────────────────────────────────────
async function executePumpFunBundle({
  creatorKeypair,
  bundleWallets, // [{ keypair, solAmount }]
  tokenData,
  imageBuffer,
  devBuyAmountSol
}) {
  const mintKeypair = Keypair.generate();
  console.log('🎯 Mint:', mintKeypair.publicKey.toBase58());

  // 1. Upload metadata
  console.log('📦 Uploading metadata...');
  const meta = await uploadPumpFunMetadata(tokenData, imageBuffer);
  const metadataUri = meta.metadataUri;

  // 2. Create + sign launch tx
  console.log('🔧 Building launch tx...');
  const launchTx = await getLocalTx({
    publicKey: creatorKeypair.publicKey.toBase58(),
    action: 'create',
    tokenMetadata: { name: tokenData.name, symbol: tokenData.symbol, uri: metadataUri },
    mint: mintKeypair.publicKey.toBase58(),
    denominatedInSol: 'true',
    amount: devBuyAmountSol,
    slippage: 25,
    priorityFee: 0.001,
    pool: 'pump'
  });
  launchTx.sign([creatorKeypair, mintKeypair]);

  // 3. Build bundle buy txs
  const buyTxs = [];
  for (const w of bundleWallets) {
    if (!w.solAmount || w.solAmount <= 0) continue;
    try {
      const tx = await getLocalTx({
        publicKey: w.keypair.publicKey.toBase58(),
        action: 'buy',
        mint: mintKeypair.publicKey.toBase58(),
        denominatedInSol: 'true',
        amount: w.solAmount,
        slippage: 25,
        priorityFee: 0.0003,
        pool: 'pump'
      });
      tx.sign([w.keypair]);
      buyTxs.push({ tx, keypair: w.keypair });
    } catch (err) {
      console.warn(`Buy tx failed for wallet ${w.keypair.publicKey.toBase58()}:`, err.message);
    }
  }

  // 4. Encode and send bundle (max 5 txs per Jito bundle)
  const allTxs = [launchTx, ...buyTxs.map(b => b.tx)];
  const encoded = allTxs.map(tx => Buffer.from(tx.serialize()).toString('base64'));

  // Jito max is 5 txs per bundle
  const chunks = [];
  for (let i = 0; i < encoded.length; i += 5) chunks.push(encoded.slice(i, i + 5));

  const bundleResults = [];
  for (const chunk of chunks) {
    const result = await sendJitoBundle(chunk);
    bundleResults.push(result);
    if (!result.success) {
      // Fallback: send individually
      const conn = getConnection();
      for (const enc of chunk) {
        try {
          const rawTx = Buffer.from(enc, 'base64');
          const sig = await conn.sendRawTransaction(rawTx, { skipPreflight: false });
          bundleResults.push({ success: true, signature: sig });
        } catch (e) {
          bundleResults.push({ success: false, error: e.message });
        }
      }
    }
  }

  return {
    mintAddress: mintKeypair.publicKey.toBase58(),
    metadataUri,
    tokenUrl: `https://pump.fun/${mintKeypair.publicKey.toBase58()}`,
    bundleResults,
    txCount: allTxs.length
  };
}

module.exports = { uploadPumpFunMetadata, executePumpFunBundle, sendJitoBundle };
