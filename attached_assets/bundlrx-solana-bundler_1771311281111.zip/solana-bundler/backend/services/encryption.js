const crypto = require('crypto');
const { Keypair } = require('@solana/web3.js');
const bs58 = require('bs58');

const ALGORITHM = 'aes-256-gcm';
const KEY_LEN = 32;
const IV_LEN = 16;
const TAG_LEN = 16;
const SALT_LEN = 32;
const PBKDF2_ITER = 150000; // Higher = more secure

/**
 * Derive AES key from password + salt via PBKDF2
 */
function deriveKey(password, saltHex) {
  return crypto.pbkdf2Sync(password, Buffer.from(saltHex, 'hex'), PBKDF2_ITER, KEY_LEN, 'sha256');
}

/**
 * Encrypt a private key string with AES-256-GCM
 * Returns: base64(iv + tag + ciphertext)
 */
function encryptPrivateKey(privateKeyBase58, password, saltHex) {
  const key = deriveKey(password, saltHex);
  const iv = crypto.randomBytes(IV_LEN);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);

  const enc = Buffer.concat([
    cipher.update(privateKeyBase58, 'utf8'),
    cipher.final()
  ]);
  const tag = cipher.getAuthTag();

  const payload = Buffer.concat([iv, tag, enc]);
  return payload.toString('base64');
}

/**
 * Decrypt a private key — throws on bad password/tampered data
 */
function decryptPrivateKey(encryptedBase64, password, saltHex) {
  const key = deriveKey(password, saltHex);
  const payload = Buffer.from(encryptedBase64, 'base64');

  const iv  = payload.subarray(0, IV_LEN);
  const tag = payload.subarray(IV_LEN, IV_LEN + TAG_LEN);
  const enc = payload.subarray(IV_LEN + TAG_LEN);

  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(tag);

  return Buffer.concat([decipher.update(enc), decipher.final()]).toString('utf8');
}

/**
 * Generate N Solana keypairs
 */
function generateUserWallets(count = 12) {
  return Array.from({ length: count }, (_, i) => {
    const kp = Keypair.generate();
    return {
      index: i,
      publicKey: kp.publicKey.toBase58(),
      privateKey: bs58.encode(kp.secretKey)
    };
  });
}

/**
 * Reconstruct a Keypair from encrypted storage
 */
function keypairFromEncrypted(encryptedPrivateKey, password, saltHex) {
  const privateKeyBase58 = decryptPrivateKey(encryptedPrivateKey, password, saltHex);
  return Keypair.fromSecretKey(bs58.decode(privateKeyBase58));
}

/**
 * Generate a new random encryption salt
 */
function generateSalt() {
  return crypto.randomBytes(SALT_LEN).toString('hex');
}

module.exports = {
  encryptPrivateKey,
  decryptPrivateKey,
  generateUserWallets,
  keypairFromEncrypted,
  generateSalt
};
