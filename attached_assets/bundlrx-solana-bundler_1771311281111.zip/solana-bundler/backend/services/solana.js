const { Connection, PublicKey, LAMPORTS_PER_SOL, SystemProgram, Transaction } = require('@solana/web3.js');

let _connection;

function getConnection() {
  if (!_connection) {
    const rpc = process.env.HELIUS_API_KEY
      ? `https://mainnet.helius-rpc.com/?api-key=${process.env.HELIUS_API_KEY}`
      : (process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com');

    _connection = new Connection(rpc, {
      commitment: 'confirmed',
      confirmTransactionInitialTimeout: 90000
    });
  }
  return _connection;
}

async function getSolBalance(publicKey) {
  try {
    const bal = await getConnection().getBalance(new PublicKey(publicKey));
    return bal / LAMPORTS_PER_SOL;
  } catch { return 0; }
}

async function getMultipleBalances(publicKeys) {
  const results = await Promise.allSettled(
    publicKeys.map(pk => getConnection().getBalance(new PublicKey(pk)))
  );
  return publicKeys.map((pk, i) => ({
    publicKey: pk,
    balance: results[i].status === 'fulfilled' ? results[i].value / LAMPORTS_PER_SOL : 0
  }));
}

async function sendSol(fromKeypair, toPublicKey, amountSol) {
  try {
    const conn = getConnection();
    const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
    const tx = new Transaction({
      recentBlockhash: blockhash,
      feePayer: fromKeypair.publicKey
    }).add(SystemProgram.transfer({
      fromPubkey: fromKeypair.publicKey,
      toPubkey: new PublicKey(toPublicKey),
      lamports: Math.floor(amountSol * LAMPORTS_PER_SOL)
    }));

    tx.sign(fromKeypair);
    const sig = await conn.sendRawTransaction(tx.serialize());
    await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight });
    return { success: true, signature: sig };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

function isValidPublicKey(key) {
  try { new PublicKey(key); return true; } catch { return false; }
}

async function getRecentBlockhash() {
  return getConnection().getLatestBlockhash();
}

module.exports = { getConnection, getSolBalance, getMultipleBalances, sendSol, isValidPublicKey, getRecentBlockhash };
