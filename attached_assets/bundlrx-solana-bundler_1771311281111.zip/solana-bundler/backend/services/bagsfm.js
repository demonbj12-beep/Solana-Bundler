/**
 * bags.fm Integration
 * bags.fm is a Solana token launchpad with fee-share mechanics
 */

const fetch = require('node-fetch');
const FormData = require('form-data');
const { Keypair, VersionedTransaction, LAMPORTS_PER_SOL } = require('@solana/web3.js');
const { getConnection } = require('./solana');
const { sendJitoBundle } = require('./pumpfun');

const BAGS_API = 'https://public-api-v2.bags.fm/api/v1';
const BAGS_API_KEY = process.env.BAGS_API_KEY || '';

function bagsHeaders(extra = {}) {
  return { 'Content-Type': 'application/json', 'x-api-key': BAGS_API_KEY, ...extra };
}

// ─── Upload Image ───────────────────────────────────────────────────────────
async function uploadBagsImage(imageBuffer) {
  const form = new FormData();
  form.append('file', imageBuffer, { filename: 'token.png', contentType: 'image/png' });

  const res = await fetch(`${BAGS_API}/token-launch/upload`, {
    method: 'POST',
    headers: { 'x-api-key': BAGS_API_KEY, ...form.getHeaders() },
    body: form
  });

  if (!res.ok) throw new Error(`Bags image upload failed: ${await res.text()}`);
  const data = await res.json();
  return data.url || data.imageUrl || '';
}

// ─── Upload Metadata ────────────────────────────────────────────────────────
async function uploadBagsMetadata(tokenData, imageBuffer) {
  let imageUrl = '';
  if (imageBuffer) imageUrl = await uploadBagsImage(imageBuffer);

  const res = await fetch(`${BAGS_API}/token-launch/metadata`, {
    method: 'POST',
    headers: bagsHeaders(),
    body: JSON.stringify({
      name: tokenData.name,
      symbol: tokenData.symbol,
      description: tokenData.description || '',
      image: imageUrl,
      twitter: tokenData.twitter || '',
      telegram: tokenData.telegram || '',
      website: tokenData.website || ''
    })
  });

  if (!res.ok) throw new Error(`Bags metadata upload failed: ${await res.text()}`);
  const data = await res.json();
  return { metadataUri: data.uri || data.metadataUri, imageUrl };
}

// ─── Create Fee Share Config ────────────────────────────────────────────────
async function createBagsFeeConfig(payerPublicKey) {
  const res = await fetch(`${BAGS_API}/fee-share/config`, {
    method: 'POST',
    headers: bagsHeaders(),
    body: JSON.stringify({
      payer: payerPublicKey,
      feeClaimers: [{ user: payerPublicKey, userBps: 10000 }]
    })
  });

  if (!res.ok) {
    console.warn('Could not create fee config:', await res.text());
    return { configKey: null };
  }
  return res.json();
}

// ─── Build Launch Tx ────────────────────────────────────────────────────────
async function buildBagsLaunchTx({ mintPublicKey, creatorPublicKey, metadataUri, configKey, devBuyLamports }) {
  const res = await fetch(`${BAGS_API}/token-launch/create`, {
    method: 'POST',
    headers: bagsHeaders(),
    body: JSON.stringify({
      metadataUrl: metadataUri,
      tokenMint: mintPublicKey,
      launchWallet: creatorPublicKey,
      initialBuyLamports: devBuyLamports || 0,
      configKey: configKey || undefined
    })
  });

  if (!res.ok) throw new Error(`Bags launch tx failed: ${await res.text()}`);
  const buf = await res.arrayBuffer();
  return VersionedTransaction.deserialize(new Uint8Array(buf));
}

// ─── Build Buy Tx ───────────────────────────────────────────────────────────
async function buildBagsBuyTx({ buyerPublicKey, mintAddress, amountLamports }) {
  const res = await fetch(`${BAGS_API}/token/buy`, {
    method: 'POST',
    headers: bagsHeaders(),
    body: JSON.stringify({ buyer: buyerPublicKey, mint: mintAddress, amount: amountLamports, slippage: 2500 })
  });

  if (!res.ok) throw new Error(`Bags buy tx failed: ${await res.text()}`);
  const buf = await res.arrayBuffer();
  return VersionedTransaction.deserialize(new Uint8Array(buf));
}

// ─── Full Bundle ────────────────────────────────────────────────────────────
async function executeBagsBundle({ creatorKeypair, bundleWallets, tokenData, imageBuffer, devBuyAmountSol }) {
  const mintKeypair = Keypair.generate();
  console.log('🎯 Mint (bags.fm):', mintKeypair.publicKey.toBase58());

  console.log('📦 Uploading metadata to bags.fm...');
  const { metadataUri } = await uploadBagsMetadata(tokenData, imageBuffer);

  console.log('⚙️ Creating fee share config...');
  const { configKey } = await createBagsFeeConfig(creatorKeypair.publicKey.toBase58());

  console.log('🔧 Building bags.fm launch tx...');
  const launchTx = await buildBagsLaunchTx({
    mintPublicKey: mintKeypair.publicKey.toBase58(),
    creatorPublicKey: creatorKeypair.publicKey.toBase58(),
    metadataUri,
    configKey,
    devBuyLamports: Math.floor(devBuyAmountSol * LAMPORTS_PER_SOL)
  });
  launchTx.sign([creatorKeypair, mintKeypair]);

  const buyTxs = [];
  for (const w of bundleWallets) {
    if (!w.solAmount || w.solAmount <= 0) continue;
    try {
      const tx = await buildBagsBuyTx({
        buyerPublicKey: w.keypair.publicKey.toBase58(),
        mintAddress: mintKeypair.publicKey.toBase58(),
        amountLamports: Math.floor(w.solAmount * LAMPORTS_PER_SOL)
      });
      tx.sign([w.keypair]);
      buyTxs.push(tx);
    } catch (err) {
      console.warn('Bags buy tx error:', err.message);
    }
  }

  const allTxs = [launchTx, ...buyTxs];
  const encoded = allTxs.map(tx => Buffer.from(tx.serialize()).toString('base64'));
  const chunks = [];
  for (let i = 0; i < encoded.length; i += 5) chunks.push(encoded.slice(i, i + 5));

  const bundleResults = [];
  for (const chunk of chunks) bundleResults.push(await sendJitoBundle(chunk));

  return {
    mintAddress: mintKeypair.publicKey.toBase58(),
    metadataUri,
    tokenUrl: `https://bags.fm/${mintKeypair.publicKey.toBase58()}`,
    bundleResults,
    txCount: allTxs.length
  };
}

module.exports = { uploadBagsMetadata, executeBagsBundle };
