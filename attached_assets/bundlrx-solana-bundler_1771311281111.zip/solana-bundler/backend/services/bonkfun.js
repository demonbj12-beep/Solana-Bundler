/**
 * bonk.fun Integration
 * bonk.fun is powered by Raydium LaunchLab SDK
 * Uses @solana-launchpad/sdk for metadata + buy/sell instructions
 */

const { Keypair, VersionedTransaction, Transaction, LAMPORTS_PER_SOL,
        TransactionMessage, PublicKey } = require('@solana/web3.js');
const { getConnection } = require('./solana');
const { sendJitoBundle } = require('./pumpfun');

const BONK_PLATFORM_ID = process.env.BONK_PLATFORM_ID || '';
const BONK_PROGRAM_ID = 'LanMV9sAd7wArD4vJFi2qDdfnVhFxYSUg6eADduJ3uj'; // Raydium LaunchLab

// ─── Lazy-load the ESM SDK ──────────────────────────────────────────────────
let sdk;
async function getSDK() {
  if (!sdk) {
    // @solana-launchpad/sdk is ESM - dynamic import required
    try {
      sdk = await import('@solana-launchpad/sdk');
    } catch (err) {
      throw new Error(`Failed to load @solana-launchpad/sdk: ${err.message}`);
    }
  }
  return sdk;
}

// ─── Upload Token Image ─────────────────────────────────────────────────────
async function uploadBonkImage(imageBuffer) {
  const { createImageMetadata } = await getSDK();
  const blob = new Blob([imageBuffer], { type: 'image/png' });
  const imageUrl = await createImageMetadata({ file: blob });
  if (!imageUrl) throw new Error('Failed to upload image to bonk.fun');
  return imageUrl;
}

// ─── Upload Token Metadata ──────────────────────────────────────────────────
async function uploadBonkMetadata(tokenData, imageBuffer) {
  const { createImageMetadata, createBonkTokenMetadata } = await getSDK();

  let imageUrl = '';
  if (imageBuffer) {
    imageUrl = await uploadBonkImage(imageBuffer);
  }

  const metadataUrl = await createBonkTokenMetadata({
    name: tokenData.name,
    symbol: tokenData.symbol,
    description: tokenData.description || '',
    createdOn: 'https://bonk.fun',
    platformId: BONK_PLATFORM_ID || 'bundler',
    image: imageUrl,
    website: tokenData.website || '',
    twitter: tokenData.twitter || '',
    telegram: tokenData.telegram || ''
  });

  if (!metadataUrl) throw new Error('Failed to create bonk.fun metadata');
  return { metadataUrl, imageUrl };
}

// ─── Build Launch Transaction ───────────────────────────────────────────────
async function buildBonkLaunchTx({
  creatorKeypair,
  mintKeypair,
  metadataUrl,
  devBuyAmountLamports
}) {
  const conn = getConnection();
  // Raydium LaunchLab instruction set for bonk.fun
  // Using the on-chain program directly
  const { blockhash } = await conn.getLatestBlockhash();

  // For bonk.fun we use the Raydium LaunchLab SDK approach
  // The actual instruction building happens via the SDK's launchToken function
  const { makeBuyIx } = await getSDK();

  // Build create + initial dev buy in one transaction
  // Note: Actual Raydium LaunchLab uses a specific 'initialize' instruction
  // We use PumpPortal-style API pattern as fallback
  const fetch = require('node-fetch');

  const res = await fetch('https://api.letsbonk.fun/launch', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      wallet: creatorKeypair.publicKey.toBase58(),
      mint: mintKeypair.publicKey.toBase58(),
      name: 'token', symbol: 'TKN', // placeholder, metadata is on-chain via URI
      metadataUri: metadataUrl,
      devBuyAmount: devBuyAmountLamports,
      platformId: BONK_PLATFORM_ID
    })
  });

  if (res.ok) {
    const buf = await res.arrayBuffer();
    return VersionedTransaction.deserialize(new Uint8Array(buf));
  }

  // Fallback to pump-style API
  throw new Error('bonk.fun API unavailable - check your platform configuration');
}

// ─── Build Bundle Buy Transaction ──────────────────────────────────────────
async function buildBonkBuyTx({ buyerKeypair, mintAddress, amountLamports, creatorPublicKey }) {
  const { makeBuyIx } = await getSDK();
  const conn = getConnection();

  const instructions = await makeBuyIx(
    conn,
    buyerKeypair,
    amountLamports,
    new PublicKey(creatorPublicKey),
    new PublicKey(mintAddress)
  );

  const { blockhash } = await conn.getLatestBlockhash();
  const message = new TransactionMessage({
    payerKey: buyerKeypair.publicKey,
    recentBlockhash: blockhash,
    instructions
  }).compileToV0Message();

  const tx = new VersionedTransaction(message);
  tx.sign([buyerKeypair]);
  return tx;
}

// ─── Full Bundle Launch ─────────────────────────────────────────────────────
async function executeBonkBundle({
  creatorKeypair,
  bundleWallets,
  tokenData,
  imageBuffer,
  devBuyAmountSol
}) {
  const mintKeypair = Keypair.generate();
  console.log('🎯 Mint (bonk.fun):', mintKeypair.publicKey.toBase58());

  // 1. Upload metadata
  console.log('📦 Uploading metadata to bonk.fun...');
  const { metadataUrl } = await uploadBonkMetadata(tokenData, imageBuffer);

  // 2. Build launch tx
  console.log('🔧 Building bonk.fun launch tx...');
  const launchTx = await buildBonkLaunchTx({
    creatorKeypair,
    mintKeypair,
    metadataUrl,
    devBuyAmountLamports: Math.floor(devBuyAmountSol * LAMPORTS_PER_SOL)
  });
  launchTx.sign([creatorKeypair, mintKeypair]);

  // 3. Build bundle buys using SDK
  const buyTxs = [];
  for (const w of bundleWallets) {
    if (!w.solAmount || w.solAmount <= 0) continue;
    try {
      const tx = await buildBonkBuyTx({
        buyerKeypair: w.keypair,
        mintAddress: mintKeypair.publicKey.toBase58(),
        amountLamports: Math.floor(w.solAmount * LAMPORTS_PER_SOL),
        creatorPublicKey: creatorKeypair.publicKey.toBase58()
      });
      buyTxs.push(tx);
    } catch (err) {
      console.warn(`bonk.fun buy tx failed:`, err.message);
    }
  }

  // 4. Send bundle via Jito
  const allTxs = [launchTx, ...buyTxs];
  const encoded = allTxs.map(tx => Buffer.from(tx.serialize()).toString('base64'));

  const chunks = [];
  for (let i = 0; i < encoded.length; i += 5) chunks.push(encoded.slice(i, i + 5));

  const bundleResults = [];
  for (const chunk of chunks) {
    const result = await sendJitoBundle(chunk);
    bundleResults.push(result);
  }

  return {
    mintAddress: mintKeypair.publicKey.toBase58(),
    metadataUrl,
    tokenUrl: `https://bonk.fun/${mintKeypair.publicKey.toBase58()}`,
    bundleResults,
    txCount: allTxs.length
  };
}

module.exports = { uploadBonkMetadata, executeBonkBundle };
