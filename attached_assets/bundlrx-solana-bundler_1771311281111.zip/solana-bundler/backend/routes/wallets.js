const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { requireAuth } = require('../middleware/auth');
const { run, get, all } = require('../services/database');
const { getMultipleBalances } = require('../services/solana');
const { decryptPrivateKey } = require('../services/encryption');

// GET /api/wallets
router.get('/', requireAuth, async (req, res) => {
  try {
    const wallets = await all(
      'SELECT id, wallet_index, public_key, label, sol_balance, last_sync, created_at FROM wallets WHERE user_id = ? ORDER BY wallet_index',
      [req.user.id]
    );
    res.json({ wallets });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch wallets' });
  }
});

// GET /api/wallets/balances - sync from chain
router.get('/balances', requireAuth, async (req, res) => {
  try {
    const wallets = await all('SELECT id, public_key FROM wallets WHERE user_id = ? ORDER BY wallet_index', [req.user.id]);
    if (!wallets.length) return res.json({ wallets: [] });

    const balances = await getMultipleBalances(wallets.map(w => w.public_key));

    for (const { publicKey, balance } of balances) {
      await run('UPDATE wallets SET sol_balance = ?, last_sync = datetime(\'now\') WHERE public_key = ? AND user_id = ?',
        [balance, publicKey, req.user.id]);
    }

    const updated = await all(
      'SELECT id, wallet_index, public_key, label, sol_balance, last_sync FROM wallets WHERE user_id = ? ORDER BY wallet_index',
      [req.user.id]
    );
    const totalSol = updated.reduce((sum, w) => sum + (w.sol_balance || 0), 0);
    res.json({ wallets: updated, totalSol: parseFloat(totalSol.toFixed(6)) });
  } catch (err) {
    console.error('Balance sync error:', err.message);
    res.status(500).json({ error: 'Failed to sync balances' });
  }
});

// PUT /api/wallets/:id/label
router.put('/:id/label', requireAuth, async (req, res) => {
  const { label } = req.body;
  if (!label?.trim()) return res.status(400).json({ error: 'Label required' });
  try {
    await run('UPDATE wallets SET label = ? WHERE id = ? AND user_id = ?', [label.trim(), req.params.id, req.user.id]);
    res.json({ message: 'Label updated' });
  } catch {
    res.status(500).json({ error: 'Failed to update label' });
  }
});

// POST /api/wallets/:id/export - export private key (requires password)
router.post('/:id/export', requireAuth, async (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Password required' });

  try {
    const user = await get('SELECT password_hash, encryption_salt FROM users WHERE id = ?', [req.user.id]);
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Wrong password' });

    const wallet = await get(
      'SELECT public_key, encrypted_private_key FROM wallets WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]
    );
    if (!wallet) return res.status(404).json({ error: 'Wallet not found' });

    const privateKey = decryptPrivateKey(wallet.encrypted_private_key, password, user.encryption_salt);

    res.json({
      publicKey: wallet.public_key,
      privateKey,
      warning: '⚠️ NEVER share your private key with anyone. Store it securely offline.'
    });
  } catch (err) {
    console.error('Export error:', err.message);
    res.status(500).json({ error: 'Export failed — check password and try again' });
  }
});

// POST /api/wallets/export-all - export all wallets (requires password)
router.post('/export-all', requireAuth, async (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Password required' });

  try {
    const user = await get('SELECT password_hash, encryption_salt FROM users WHERE id = ?', [req.user.id]);
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Wrong password' });

    const wallets = await all(
      'SELECT id, wallet_index, public_key, encrypted_private_key, label FROM wallets WHERE user_id = ? ORDER BY wallet_index',
      [req.user.id]
    );

    const exported = wallets.map(w => ({
      index: w.wallet_index,
      label: w.label,
      publicKey: w.public_key,
      privateKey: decryptPrivateKey(w.encrypted_private_key, password, user.encryption_salt)
    }));

    res.json({
      wallets: exported,
      warning: '⚠️ NEVER share your private keys with anyone. Store them securely offline.',
      exportedAt: new Date().toISOString()
    });
  } catch (err) {
    console.error('Export all error:', err.message);
    res.status(500).json({ error: 'Export failed' });
  }
});

module.exports = router;
