// dashboard.js
const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { get, all } = require('../services/database');

router.get('/stats', requireAuth, async (req, res) => {
  try {
    const launches = await all('SELECT * FROM launches WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
    const successful = launches.filter(l => l.status === 'success');
    const totalSpent = launches.reduce((s, l) => s + (l.initial_sol_spent || 0) + (l.bundle_sol_total || 0), 0);
    const totalFees = launches.reduce((s, l) => s + (l.fee_sol || 0), 0);
    const feesPaid = launches.filter(l => l.fee_paid).reduce((s, l) => s + (l.fee_sol || 0), 0);

    const byPlatform = {};
    for (const l of launches) {
      byPlatform[l.launchpad] = (byPlatform[l.launchpad] || 0) + 1;
    }

    res.json({
      totalLaunches: launches.length,
      successfulLaunches: successful.length,
      failedLaunches: launches.filter(l => l.status === 'failed').length,
      pendingLaunches: launches.filter(l => l.status === 'pending').length,
      totalSolSpent: parseFloat(totalSpent.toFixed(6)),
      totalFeesOwed: parseFloat(totalFees.toFixed(6)),
      totalFeesPaid: parseFloat(feesPaid.toFixed(6)),
      feesUnpaid: parseFloat((totalFees - feesPaid).toFixed(6)),
      launchpadBreakdown: byPlatform,
      recentLaunches: launches.slice(0, 5)
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

module.exports = router;
