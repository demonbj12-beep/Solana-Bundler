const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');
const { requireAuth } = require('../middleware/auth');
const { run, get, all } = require('../services/database');
const { keypairFromEncrypted } = require('../services/encryption');
const { sendSol, isValidPublicKey } = require('../services/solana');

const FEE_WALLET = process.env.PLATFORM_FEE_WALLET || '';
const FEE_PCT = parseFloat(process.env.FEE_PERCENTAGE || '5') / 100;

router.get('/pending', requireAuth, async (req, res) => {
  try {
    const unpaid = await all(
      "SELECT * FROM launches WHERE user_id = ? AND status = 'success' AND fee_paid = 0 AND fee_sol > 0 ORDER BY created_at DESC",
      [req.user.id]
    );
    const total = unpaid.reduce((s, l) => s + (l.fee_sol || 0), 0);
    res.json({ launches: unpaid, totalOwed: parseFloat(total.toFixed(6)), feeWallet: FEE_WALLET });
  } catch { res.status(500).json({ error: 'Failed to fetch pending fees' }); }
});

router.post('/pay/:launchId', requireAuth, async (req, res) => {
  const { password, payerWalletIndex } = req.body;
  if (!password) return res.status(400).json({ error: 'Password required' });
  if (!FEE_WALLET || !isValidPublicKey(FEE_WALLET))
    return res.status(500).json({ error: 'Platform fee wallet not configured' });

  try {
    const launch = await get(
      "SELECT * FROM launches WHERE id = ? AND user_id = ? AND status = 'success'",
      [req.params.launchId, req.user.id]
    );
    if (!launch) return res.status(404).json({ error: 'Launch not found' });
    if (launch.fee_paid) return res.status(400).json({ error: 'Fee already paid' });

    const user = await get('SELECT password_hash, encryption_salt FROM users WHERE id = ?', [req.user.id]);
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Wrong password' });

    const walletIdx = parseInt(payerWalletIndex ?? 0);
    const wallet = await get('SELECT * FROM wallets WHERE user_id = ? AND wallet_index = ?', [req.user.id, walletIdx]);
    if (!wallet) return res.status(404).json({ error: 'Wallet not found' });

    const keypair = keypairFromEncrypted(wallet.encrypted_private_key, password, user.encryption_salt);
    const result = await sendSol(keypair, FEE_WALLET, launch.fee_sol);
    if (!result.success) return res.status(500).json({ error: `Payment failed: ${result.error}` });

    await run("UPDATE launches SET fee_paid = 1, fee_tx = ? WHERE id = ?", [result.signature, launch.id]);
    await run(
      'INSERT INTO fee_transactions (id, user_id, launch_id, amount_sol, fee_wallet, tx_signature, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [uuid(), req.user.id, launch.id, launch.fee_sol, FEE_WALLET, result.signature, 'confirmed']
    );

    res.json({ success: true, signature: result.signature, amountPaid: launch.fee_sol });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/history', requireAuth, async (req, res) => {
  try {
    const fees = await all('SELECT * FROM fee_transactions WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
    res.json({ fees });
  } catch { res.status(500).json({ error: 'Failed to fetch history' }); }
});

module.exports = router;
