const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { v4: uuid } = require('uuid');
const { body, validationResult } = require('express-validator');

const { run, get } = require('../services/database');
const { generateAccessToken, generateRefreshToken, verifyToken } = require('../middleware/auth');
const { generateUserWallets, encryptPrivateKey, generateSalt } = require('../services/encryption');

const BCRYPT_ROUNDS = 12;

const validate = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 8 }).withMessage('Password must be 8+ characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('Need uppercase, lowercase, and digit')
];

// POST /api/auth/register
router.post('/register', validate, async (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });

  const { email, password } = req.body;

  try {
    const existing = await get('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) return res.status(409).json({ error: 'Email already registered' });

    const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);
    const encryptionSalt = generateSalt();
    const userId = uuid();

    await run(
      'INSERT INTO users (id, email, password_hash, encryption_salt) VALUES (?, ?, ?, ?)',
      [userId, email, passwordHash, encryptionSalt]
    );

    // Generate 12 wallets and encrypt them
    const wallets = generateUserWallets(12);
    for (const w of wallets) {
      const encrypted = encryptPrivateKey(w.privateKey, password, encryptionSalt);
      await run(
        'INSERT INTO wallets (id, user_id, wallet_index, public_key, encrypted_private_key, label) VALUES (?, ?, ?, ?, ?, ?)',
        [uuid(), userId, w.index, w.publicKey, encrypted, `Wallet ${w.index + 1}`]
      );
    }

    const accessToken = generateAccessToken(userId, email);
    const refreshToken = generateRefreshToken(userId);
    const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    const expiresAt = new Date(Date.now() + 30 * 86400000).toISOString();
    await run(
      'INSERT INTO sessions (id, user_id, refresh_token_hash, expires_at, ip_address) VALUES (?, ?, ?, ?, ?)',
      [uuid(), userId, tokenHash, expiresAt, req.ip]
    );
    await run('UPDATE users SET last_login = datetime(\'now\') WHERE id = ?', [userId]);

    res.status(201).json({
      message: '12 wallets created. Keep your password safe — it\'s the only way to export private keys.',
      accessToken, refreshToken,
      user: { id: userId, email, walletCount: 12 }
    });
  } catch (err) {
    console.error('Register error:', err.message);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

  try {
    const user = await get('SELECT * FROM users WHERE email = ?', [email.toLowerCase().trim()]);
    if (!user) {
      await bcrypt.hash(password, 1); // timing safety
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    if (!user.is_active) return res.status(401).json({ error: 'Account disabled' });

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const accessToken = generateAccessToken(user.id, user.email);
    const refreshToken = generateRefreshToken(user.id);
    const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    const expiresAt = new Date(Date.now() + 30 * 86400000).toISOString();
    await run(
      'INSERT INTO sessions (id, user_id, refresh_token_hash, expires_at, ip_address) VALUES (?, ?, ?, ?, ?)',
      [uuid(), user.id, tokenHash, expiresAt, req.ip]
    );
    await run('UPDATE users SET last_login = datetime(\'now\') WHERE id = ?', [user.id]);

    const walletCount = (await get('SELECT COUNT(*) as c FROM wallets WHERE user_id = ?', [user.id]))?.c || 0;
    res.json({ accessToken, refreshToken, user: { id: user.id, email: user.email, walletCount } });
  } catch (err) {
    console.error('Login error:', err.message);
    res.status(500).json({ error: 'Login failed' });
  }
});

// POST /api/auth/refresh
router.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(401).json({ error: 'Refresh token required' });

  try {
    const decoded = verifyToken(refreshToken);
    if (decoded.type !== 'refresh') return res.status(401).json({ error: 'Invalid token' });

    const hash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    const session = await get('SELECT * FROM sessions WHERE refresh_token_hash = ?', [hash]);
    if (!session || new Date(session.expires_at) < new Date()) {
      if (session) await run('DELETE FROM sessions WHERE id = ?', [session.id]);
      return res.status(401).json({ error: 'Session expired' });
    }

    const user = await get('SELECT id, email FROM users WHERE id = ?', [session.user_id]);
    if (!user) return res.status(401).json({ error: 'User not found' });

    res.json({ accessToken: generateAccessToken(user.id, user.email) });
  } catch {
    res.status(401).json({ error: 'Invalid refresh token' });
  }
});

// POST /api/auth/logout
router.post('/logout', async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    const hash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    await run('DELETE FROM sessions WHERE refresh_token_hash = ?', [hash]).catch(() => {});
  }
  res.json({ message: 'Logged out' });
});

module.exports = router;
