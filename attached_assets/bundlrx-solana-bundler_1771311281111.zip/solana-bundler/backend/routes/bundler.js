const express = require('express');
const router = express.Router();
const multer = require('multer');
const { v4: uuid } = require('uuid');
const bcrypt = require('bcryptjs');
const { requireAuth } = require('../middleware/auth');
const { run, get, all } = require('../services/database');
const { keypairFromEncrypted, decryptPrivateKey } = require('../services/encryption');
const { getSolBalance, isValidPublicKey } = require('../services/solana');
const { executePumpFunBundle } = require('../services/pumpfun');
const { executeBonkBundle } = require('../services/bonkfun');
const { executeBagsBundle } = require('../services/bagsfm');
const { sendSol } = require('../services/solana');

const FEE_PCT = parseFloat(process.env.FEE_PERCENTAGE || '5') / 100;
const FEE_WALLET = process.env.PLATFORM_FEE_WALLET || '';

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
    cb(null, allowed.includes(file.mimetype));
  }
});

// ─── GET /api/bundler/config ─────────────────────────────────────────────────
// Returns public bundle config info
router.get('/config', requireAuth, async (req, res) => {
  res.json({
    launchpads: ['pump.fun', 'bags.fm', 'bonk.fun'],
    maxBundleWallets: 12,
    feePercentage: FEE_PCT * 100,
    feeWallet: FEE_WALLET,
    hasFeeWallet: Boolean(FEE_WALLET && isValidPublicKey(FEE_WALLET))
  });
});

// ─── POST /api/bundler/estimate ──────────────────────────────────────────────
// Estimate costs before launch
router.post('/estimate', requireAuth, async (req, res) => {
  const { walletIndices, solPerWallet, devBuyAmountSol } = req.body;
  if (!walletIndices?.length || !solPerWallet) return res.status(400).json({ error: 'Missing params' });

  const walletCount = walletIndices.length;
  const bundleTotal = parseFloat(solPerWallet) * walletCount;
  const devBuy = parseFloat(devBuyAmountSol || 0);
  const totalSpend = bundleTotal + devBuy;
  const estimatedFee = totalSpend * FEE_PCT; // 5% of gross spend as indicator
  const jitoTip = 0.001 * walletCount;

  res.json({
    walletCount,
    solPerWallet: parseFloat(solPerWallet),
    bundleTotal: parseFloat(bundleTotal.toFixed(6)),
    devBuyAmountSol: devBuy,
    totalSpend: parseFloat(totalSpend.toFixed(6)),
    estimatedFee: parseFloat(estimatedFee.toFixed(6)),
    jitoTip: parseFloat(jitoTip.toFixed(6)),
    feePercentage: FEE_PCT * 100,
    note: `${FEE_PCT * 100}% fee collected AFTER successful launch`
  });
});

// ─── POST /api/bundler/launch ────────────────────────────────────────────────
// Main bundled launch endpoint
router.post('/launch', requireAuth, upload.single('image'), async (req, res) => {
  const {
    password,
    launchpad,         // 'pump.fun' | 'bags.fm' | 'bonk.fun'
    tokenName,
    tokenSymbol,
    tokenDescription,
    twitter,
    telegram,
    website,
    devBuyAmountSol,
    walletIndices,     // JSON array of wallet indices to bundle
    solPerWallet       // SOL per bundle wallet
  } = req.body;

  // Validation
  if (!password) return res.status(400).json({ error: 'Password required to decrypt wallets' });
  if (!launchpad) return res.status(400).json({ error: 'Launchpad required' });
  if (!['pump.fun', 'bags.fm', 'bonk.fun'].includes(launchpad)) {
    return res.status(400).json({ error: 'Invalid launchpad. Use: pump.fun, bags.fm, bonk.fun' });
  }
  if (!tokenName || !tokenSymbol) return res.status(400).json({ error: 'Token name and symbol required' });

  let parsedIndices;
  try {
    parsedIndices = typeof walletIndices === 'string' ? JSON.parse(walletIndices) : walletIndices;
    if (!Array.isArray(parsedIndices) || parsedIndices.length === 0) throw new Error();
  } catch {
    return res.status(400).json({ error: 'walletIndices must be a non-empty JSON array' });
  }

  if (parsedIndices.length > 12) return res.status(400).json({ error: 'Max 12 bundle wallets' });

  const devBuy = parseFloat(devBuyAmountSol) || 0;
  const solEach = parseFloat(solPerWallet) || 0;
  if (solEach <= 0) return res.status(400).json({ error: 'solPerWallet must be > 0' });

  const launchId = uuid();

  try {
    // 1. Verify password
    const user = await get('SELECT password_hash, encryption_salt FROM users WHERE id = ?', [req.user.id]);
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Wrong password' });

    // 2. Load wallets
    const walletRows = await all(
      `SELECT id, wallet_index, public_key, encrypted_private_key FROM wallets
       WHERE user_id = ? AND wallet_index IN (${parsedIndices.map(() => '?').join(',')})
       ORDER BY wallet_index`,
      [req.user.id, ...parsedIndices]
    );

    if (walletRows.length === 0) return res.status(404).json({ error: 'No wallets found' });

    // Decrypt keypairs
    const bundleWallets = walletRows.map(w => ({
      keypair: keypairFromEncrypted(w.encrypted_private_key, password, user.encryption_salt),
      solAmount: solEach,
      publicKey: w.public_key,
      walletId: w.id
    }));

    // Creator is the first selected wallet (dev wallet)
    const creatorWallet = bundleWallets[0];
    const bundleOnlyWallets = bundleWallets.slice(1);

    // 3. Check creator balance
    const creatorBalance = await getSolBalance(creatorWallet.keypair.publicKey.toBase58());
    const minRequired = devBuy + 0.01; // dev buy + rent
    if (creatorBalance < minRequired) {
      return res.status(400).json({
        error: `Creator wallet (${creatorWallet.keypair.publicKey.toBase58()}) needs at least ${minRequired} SOL. Current: ${creatorBalance.toFixed(4)} SOL`
      });
    }

    // 4. Insert launch record
    const bundleSolTotal = bundleOnlyWallets.reduce((sum, w) => sum + w.solAmount, 0);
    await run(
      `INSERT INTO launches (id, user_id, token_name, token_symbol, launchpad, status, initial_sol_spent, bundle_sol_total, wallet_count)
       VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?)`,
      [launchId, req.user.id, tokenName, tokenSymbol, launchpad, devBuy, bundleSolTotal, bundleOnlyWallets.length]
    );

    const tokenData = {
      name: tokenName,
      symbol: tokenSymbol.toUpperCase(),
      description: tokenDescription || '',
      twitter: twitter || '',
      telegram: telegram || '',
      website: website || ''
    };
    const imageBuffer = req.file?.buffer || null;

    // 5. Execute bundle on chosen launchpad
    let result;
    const params = {
      creatorKeypair: creatorWallet.keypair,
      bundleWallets: bundleOnlyWallets,
      tokenData,
      imageBuffer,
      devBuyAmountSol: devBuy
    };

    try {
      if (launchpad === 'pump.fun')  result = await executePumpFunBundle(params);
      if (launchpad === 'bonk.fun')  result = await executeBonkBundle(params);
      if (launchpad === 'bags.fm')   result = await executeBagsBundle(params);
    } catch (launchErr) {
      await run('UPDATE launches SET status = ?, error_msg = ? WHERE id = ?', ['failed', launchErr.message, launchId]);
      return res.status(500).json({ error: `Launch failed: ${launchErr.message}`, launchId });
    }

    // 6. Update launch record with success
    const fee = (devBuy + bundleSolTotal) * FEE_PCT;
    await run(
      `UPDATE launches SET status = 'success', token_mint = ?, token_url = ?, fee_sol = ?, completed_at = datetime('now') WHERE id = ?`,
      [result.mintAddress, result.tokenUrl, fee, launchId]
    );

    // 7. Record bundle buys
    for (const w of bundleOnlyWallets) {
      await run(
        'INSERT INTO bundled_buys (id, launch_id, wallet_public_key, sol_amount, status) VALUES (?, ?, ?, ?, ?)',
        [uuid(), launchId, w.keypair.publicKey.toBase58(), w.solAmount, 'submitted']
      );
    }

    res.json({
      success: true,
      launchId,
      mintAddress: result.mintAddress,
      tokenUrl: result.tokenUrl,
      txCount: result.txCount,
      bundleResults: result.bundleResults,
      feeOwed: parseFloat(fee.toFixed(6)),
      feePercentage: FEE_PCT * 100,
      feeWallet: FEE_WALLET,
      message: `🚀 Token launched on ${launchpad}! Please pay the ${FEE_PCT * 100}% platform fee.`
    });
  } catch (err) {
    console.error('Launch error:', err.message, err.stack);
    await run('UPDATE launches SET status = ?, error_msg = ? WHERE id = ?', ['failed', err.message, launchId]).catch(() => {});
    res.status(500).json({ error: err.message });
  }
});

// GET /api/bundler/launches - launch history
router.get('/launches', requireAuth, async (req, res) => {
  try {
    const launches = await all(
      'SELECT * FROM launches WHERE user_id = ? ORDER BY created_at DESC LIMIT 50',
      [req.user.id]
    );
    res.json({ launches });
  } catch {
    res.status(500).json({ error: 'Failed to fetch launch history' });
  }
});

// GET /api/bundler/launches/:id
router.get('/launches/:id', requireAuth, async (req, res) => {
  try {
    const launch = await get('SELECT * FROM launches WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (!launch) return res.status(404).json({ error: 'Launch not found' });
    const buys = await all('SELECT * FROM bundled_buys WHERE launch_id = ? ORDER BY created_at', [req.params.id]);
    res.json({ launch, buys });
  } catch {
    res.status(500).json({ error: 'Failed to fetch launch' });
  }
});

module.exports = router;
