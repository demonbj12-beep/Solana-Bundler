require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const authRoutes = require('./routes/auth');
const walletRoutes = require('./routes/wallets');
const bundlerRoutes = require('./routes/bundler');
const dashboardRoutes = require('./routes/dashboard');
const feeRoutes = require('./routes/fees');

const { initDatabase } = require('./services/database');

const app = express();
const PORT = process.env.PORT || 3001;

// ─── Security Middleware ────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:", "blob:"],
      connectSrc: ["'self'",
        "https://api.mainnet-beta.solana.com",
        "https://*.helius-rpc.com",
        "https://pumpportal.fun",
        "https://pump.fun",
        "https://bonk.fun",
        "https://api.bonk.fun",
        "https://mainnet.block-engine.jito.wtf",
        "https://amsterdam.mainnet.block-engine.jito.wtf",
        "https://ny.mainnet.block-engine.jito.wtf"
      ]
    }
  }
}));

app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? process.env.FRONTEND_URL
    : ['http://localhost:3000', 'http://localhost:5173', 'http://0.0.0.0:3000'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// ─── Rate Limiters ──────────────────────────────────────────────────────────
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, max: 10,
  message: { error: 'Too many auth attempts, try again in 15 minutes.' }
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000, max: 60,
  message: { error: 'Rate limit exceeded.' }
});

const bundleLimiter = rateLimit({
  windowMs: 60 * 1000, max: 5,
  message: { error: 'Too many bundle requests. Please wait.' }
});

// ─── Body Parsing ───────────────────────────────────────────────────────────
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// ─── Routes ─────────────────────────────────────────────────────────────────
app.use('/api/auth', authLimiter, authRoutes);
app.use('/api/wallets', apiLimiter, walletRoutes);
app.use('/api/bundler', bundleLimiter, bundlerRoutes);
app.use('/api/dashboard', apiLimiter, dashboardRoutes);
app.use('/api/fees', apiLimiter, feeRoutes);

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '1.0.0',
    launchpads: ['pump.fun', 'bags.fm', 'bonk.fun'],
    timestamp: new Date().toISOString()
  });
});

// ─── Serve Frontend in Production ───────────────────────────────────────────
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../frontend/dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/dist/index.html'));
  });
}

// ─── Global Error Handler ───────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[ERROR]', err.message);
  const code = err.status || 500;
  res.status(code).json({
    error: process.env.NODE_ENV === 'production' && code === 500
      ? 'Internal server error'
      : err.message
  });
});

// ─── Start Server ───────────────────────────────────────────────────────────
initDatabase().then(() => {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n🚀 Solana Bundler API running on port ${PORT}`);
    console.log(`🌐 Launchpads: pump.fun | bags.fm | bonk.fun`);
    console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}\n`);
  });
}).catch(err => {
  console.error('❌ DB init failed:', err.message);
  process.exit(1);
});

module.exports = app;
