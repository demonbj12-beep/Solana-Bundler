# ⚡ BundlrX — Solana Token Bundler

Launch tokens on **pump.fun**, **bags.fm**, and **bonk.fun** with atomic multi-wallet bundle buys via Jito.

---

## 🚀 Quick Setup in Replit

### 1. Create Secrets (Environment Variables)
Go to Replit Secrets (🔒 lock icon) and add:

| Secret | Description |
|--------|-------------|
| `JWT_SECRET` | Random 32+ character string for auth |
| `PLATFORM_FEE_WALLET` | YOUR Solana wallet address (receives 5% fees) |
| `SOLANA_RPC_URL` | `https://api.mainnet-beta.solana.com` (or Helius) |
| `HELIUS_API_KEY` | Optional: Helius key for faster RPC |
| `BONK_PLATFORM_ID` | Optional: bonk.fun platform ID |
| `BAGS_API_KEY` | Optional: bags.fm API key |

### 2. Install & Run
```bash
# Install all deps
cd backend && npm install
cd ../frontend && npm install && npm run build
cd ..

# Start production server
cd backend && NODE_ENV=production node index.js
```

**The backend serves the built frontend. Visit port 3001.**

---

## 🔑 Features

- **3 Launchpads**: pump.fun · bags.fm · bonk.fun
- **12 Wallets** auto-generated per user on registration
- **AES-256-GCM** encryption — private keys only decryptable with your password
- **Jito Bundle** atomic execution with MEV protection
- **5% fee** auto-calculated, paid on-chain from your wallets
- **Export wallets** any time using your password
- **JWT auth** with refresh tokens

---

## 📁 Structure

```
backend/
  index.js           — Express server (port 3001)
  routes/            — auth, wallets, bundler, fees, dashboard
  services/
    pumpfun.js       — pump.fun + Jito bundling
    bonkfun.js       — bonk.fun (Raydium LaunchLab SDK)
    bagsfm.js        — bags.fm REST API
    encryption.js    — AES-256-GCM key encryption
    database.js      — SQLite via better-sqlite3
    solana.js        — Web3.js helpers

frontend/
  src/App.jsx        — Full React app (all pages)
  src/hooks/         — useAuth context
  src/utils/api.js   — Axios with token refresh
```

---

## 💸 Fee System

5% of total SOL spent → collected on-chain to your `PLATFORM_FEE_WALLET` after each successful launch. Users pay from any of their generated wallets.

---

## ⚠️ Pre-Launch Checklist

- [ ] Creator wallet (Wallet 1) funded with enough SOL for dev buy + gas
- [ ] Bundle wallets funded with SOL (each needs `solPerWallet` + ~0.001 SOL gas)
- [ ] `PLATFORM_FEE_WALLET` set to your actual Solana address
- [ ] `JWT_SECRET` set to a long random string
