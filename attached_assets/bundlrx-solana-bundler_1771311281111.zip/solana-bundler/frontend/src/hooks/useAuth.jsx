import { createContext, useContext, useState, useCallback } from 'react'
import api from '../utils/api'
const AuthCtx = createContext(null)
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => { try { return JSON.parse(localStorage.getItem('user')) } catch { return null } })
  const [loading, setLoading] = useState(false)
  const login = useCallback(async (email, password) => {
    setLoading(true)
    try {
      const { data } = await api.post('/auth/login', { email, password })
      localStorage.setItem('accessToken', data.accessToken)
      localStorage.setItem('refreshToken', data.refreshToken)
      localStorage.setItem('user', JSON.stringify(data.user))
      setUser(data.user)
      return { success: true }
    } catch (err) { return { success: false, error: err.response?.data?.error || 'Login failed' } }
    finally { setLoading(false) }
  }, [])
  const register = useCallback(async (email, password) => {
    setLoading(true)
    try {
      const { data } = await api.post('/auth/register', { email, password })
      localStorage.setItem('accessToken', data.accessToken)
      localStorage.setItem('refreshToken', data.refreshToken)
      localStorage.setItem('user', JSON.stringify(data.user))
      setUser(data.user)
      return { success: true, message: data.message }
    } catch (err) {
      const errors = err.response?.data?.errors
      const msg = errors ? errors.map(e => e.msg).join(', ') : (err.response?.data?.error || 'Failed')
      return { success: false, error: msg }
    } finally { setLoading(false) }
  }, [])
  const logout = useCallback(async () => {
    try { await api.post('/auth/logout', { refreshToken: localStorage.getItem('refreshToken') }) } catch {}
    ['accessToken','refreshToken','user'].forEach(k => localStorage.removeItem(k))
    setUser(null)
  }, [])
  return <AuthCtx.Provider value={{ user, loading, login, register, logout }}>{children}</AuthCtx.Provider>
}
export const useAuth = () => useContext(AuthCtx)
