import { BrowserRouter, Routes, Route, Navigate, Link, useLocation, useNavigate } from 'react-router-dom'
import { useState, useEffect, useCallback, useRef } from 'react'
import { AuthProvider, useAuth } from './hooks/useAuth.jsx'
import api from './utils/api.js'

// ─── Format utils ────────────────────────────────────────────────────────────
const fSol = n => n == null ? '—' : `${parseFloat(n).toFixed(4)} SOL`
const fAddr = (a, c=4) => a ? `${a.slice(0,c)}...${a.slice(-c)}` : ''
const fDate = d => d ? new Date(d).toLocaleString() : '—'
const LP_COLOR = {'pump.fun':'#00ff88','bags.fm':'#00ccff','bonk.fun':'#ff6b35'}
const LP_ICON = {'pump.fun':'🟢','bags.fm':'💎','bonk.fun':'🔥'}

// ─── Toast ────────────────────────────────────────────────────────────────────
let _tid = 0; const _tl = new Set()
export const toast = (msg, type='info', dur=4000) => { const id=++_tid; _tl.forEach(f=>f({id,msg,type,dur})) }
function Toasts() {
  const [ts, setTs] = useState([])
  useEffect(() => { const f=t=>{setTs(p=>[...p,t]);setTimeout(()=>setTs(p=>p.filter(x=>x.id!==t.id)),t.dur)}; _tl.add(f); return()=>_tl.delete(f) }, [])
  return <div style={{position:'fixed',bottom:24,right:24,zIndex:9999,display:'flex',flexDirection:'column',gap:8}}>
    {ts.map(t=><div key={t.id} style={{background:'var(--surface2)',border:`1px solid ${t.type==='success'?'rgba(0,255,136,.4)':t.type==='error'?'rgba(255,51,102,.4)':'rgba(0,204,255,.4)'}`,borderRadius:'var(--radius)',padding:'12px 16px',display:'flex',alignItems:'center',gap:10,maxWidth:340,fontSize:14,color:'var(--text)',boxShadow:'0 4px 24px rgba(0,0,0,.4)'}}>
      <span style={{fontSize:18}}>{t.type==='success'?'✅':t.type==='error'?'❌':'ℹ️'}</span><span>{t.msg}</span>
    </div>)}
  </div>
}

// ─── UI primitives ────────────────────────────────────────────────────────────
function Btn({children,variant='primary',loading,disabled,size='md',fullWidth,style={},...p}) {
  const base={display:'inline-flex',alignItems:'center',justifyContent:'center',gap:8,border:'none',borderRadius:'var(--radius)',fontFamily:'var(--font-display)',fontWeight:700,cursor:disabled||loading?'not-allowed':'pointer',opacity:disabled?.5:1,transition:'all .2s',width:fullWidth?'100%':'auto',fontSize:size==='sm'?13:size==='lg'?17:15,padding:size==='sm'?'6px 12px':size==='lg'?'14px 28px':'10px 20px'}
  const v={primary:{background:'linear-gradient(135deg,var(--accent),#00cc66)',color:'#000',boxShadow:'0 0 20px rgba(0,255,136,.2)'},secondary:{background:'var(--surface2)',color:'var(--text)',border:'1px solid var(--border2)'},danger:{background:'linear-gradient(135deg,var(--danger),#cc0033)',color:'#fff'},ghost:{background:'transparent',color:'var(--text2)',border:'1px solid var(--border)'},accent:{background:'var(--surface2)',color:'var(--accent)',border:'1px solid rgba(0,255,136,.3)'}}
  return <button style={{...base,...(v[variant]||v.primary),...style}} disabled={disabled||loading} {...p}>
    {loading&&<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{animation:'spin .8s linear infinite'}} xmlns="http://www.w3.org/2000/svg"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>}
    {children}
  </button>
}

function Field({label,error,hint,type='text',containerStyle={},...p}) {
  const [show,setShow]=useState(false); const isP=type==='password'
  return <div style={{display:'flex',flexDirection:'column',gap:6,...containerStyle}}>
    {label&&<label style={{fontSize:13,fontWeight:700,color:'var(--text2)',letterSpacing:'.05em',textTransform:'uppercase'}}>{label}</label>}
    <div style={{position:'relative',display:'flex',alignItems:'center'}}>
      <input type={isP?(show?'text':'password'):type} style={{width:'100%',background:'var(--surface)',border:`1px solid ${error?'var(--danger)':'var(--border2)'}`,borderRadius:'var(--radius)',padding:`11px ${isP?'44px':'14px'} 11px 14px`,color:'var(--text)',fontSize:15,outline:'none',transition:'border .2s'}} onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor=error?'var(--danger)':'var(--border2)'} {...p}/>
      {isP&&<button type="button" onClick={()=>setShow(!show)} style={{position:'absolute',right:12,background:'none',border:'none',color:'var(--text3)',cursor:'pointer',fontSize:13}}>{show?'🙈':'👁'}</button>}
    </div>
    {error&&<span style={{fontSize:12,color:'var(--danger)'}}>{error}</span>}
    {hint&&!error&&<span style={{fontSize:12,color:'var(--text3)'}}>{hint}</span>}
  </div>
}

function Card({children,glow,style={},...p}) {
  return <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'var(--radius-lg)',padding:24,boxShadow:glow?'0 0 30px rgba(0,255,136,.08)':'0 2px 16px rgba(0,0,0,.3)',...style}} {...p}>{children}</div>
}

function CopyBtn({text}) {
  const [ok,setOk]=useState(false)
  return <button onClick={()=>{navigator.clipboard.writeText(text);setOk(true);setTimeout(()=>setOk(false),1500)}} style={{background:'none',border:'none',color:'var(--text3)',cursor:'pointer',padding:4,borderRadius:4}} title="Copy">
    {ok?'✓':'📋'}
  </button>
}

function Stat({label,value,accent}) {
  return <div style={{display:'flex',flexDirection:'column',gap:4}}>
    <span style={{fontSize:11,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.08em',fontWeight:700}}>{label}</span>
    <span style={{fontSize:22,fontWeight:800,color:accent||'var(--text)',fontFamily:'var(--font-mono)'}}>{value}</span>
  </div>
}

// ─── Layout ───────────────────────────────────────────────────────────────────
function Sidebar() {
  const {logout,user}=useAuth(); const loc=useLocation()
  const nav=[{to:'/dashboard',e:'📊',l:'Dashboard'},{to:'/bundler',e:'🚀',l:'Bundler'},{to:'/wallets',e:'👛',l:'Wallets'},{to:'/history',e:'📋',l:'History'},{to:'/fees',e:'💸',l:'Fees'}]
  return <aside style={{width:220,minHeight:'100vh',background:'var(--bg2)',borderRight:'1px solid var(--border)',display:'flex',flexDirection:'column',position:'fixed',top:0,left:0,bottom:0,zIndex:100}}>
    <div style={{padding:'24px 20px 20px',borderBottom:'1px solid var(--border)'}}>
      <div style={{display:'flex',alignItems:'center',gap:10}}>
        <div style={{width:34,height:34,borderRadius:10,background:'linear-gradient(135deg,var(--accent),var(--accent2))',display:'flex',alignItems:'center',justifyContent:'center',fontSize:16}}>⚡</div>
        <div><div style={{fontSize:17,fontWeight:800,letterSpacing:'-0.03em'}}>BundlrX</div><div style={{fontSize:10,color:'var(--text3)',letterSpacing:'.1em',textTransform:'uppercase'}}>Solana Bundler</div></div>
      </div>
    </div>
    <nav style={{flex:1,padding:'12px 10px',display:'flex',flexDirection:'column',gap:3}}>
      {nav.map(item=>{const a=loc.pathname===item.to; return <Link key={item.to} to={item.to} style={{display:'flex',alignItems:'center',gap:10,padding:'9px 12px',borderRadius:'var(--radius)',color:a?'var(--accent)':'var(--text2)',background:a?'rgba(0,255,136,.08)':'transparent',border:`1px solid ${a?'rgba(0,255,136,.2)':'transparent'}`,fontWeight:a?700:500,fontSize:14,transition:'all .2s'}}>
        <span>{item.e}</span>{item.l}
      </Link>})}
    </nav>
    <div style={{padding:'14px 18px',borderTop:'1px solid var(--border)'}}>
      <div style={{fontSize:11,color:'var(--text3)',marginBottom:2,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{user?.email}</div>
      <button onClick={logout} style={{color:'var(--text3)',background:'none',border:'none',fontSize:13,cursor:'pointer',padding:'4px 0',marginTop:2}}>🚪 Sign out</button>
    </div>
  </aside>
}

function Layout({children}) {
  return <div style={{display:'flex',minHeight:'100vh'}}>
    <Sidebar/>
    <main style={{marginLeft:220,flex:1,padding:32,position:'relative',zIndex:1}}>{children}</main>
  </div>
}

function RequireAuth({children}) { const {user}=useAuth(); return user?children:<Navigate to="/login" replace/> }

// ─── AUTH ─────────────────────────────────────────────────────────────────────
function AuthPage({mode='login'}) {
  const {login,register,loading}=useAuth(); const nav=useNavigate()
  const [email,setEmail]=useState(''); const [pw,setPw]=useState(''); const [err,setErr]=useState(''); const [suc,setSuc]=useState('')
  const isL=mode==='login'
  const submit=async e=>{e.preventDefault();setErr('');setSuc('')
    const r=await(isL?login:register)(email,pw)
    if(r.success){if(r.message)setSuc(r.message);setTimeout(()=>nav('/dashboard'),r.message?1800:0)}else setErr(r.error)}
  return <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',padding:20,position:'relative',zIndex:1}}>
    <div style={{width:'100%',maxWidth:420}}>
      <div style={{textAlign:'center',marginBottom:36}}>
        <div style={{fontSize:52,marginBottom:10}}>⚡</div>
        <h1 style={{fontSize:34,fontWeight:800,letterSpacing:'-0.04em',marginBottom:4}}>Bundlr<span style={{color:'var(--accent)'}}>X</span></h1>
        <p style={{color:'var(--text2)',fontSize:13}}>Launch on pump.fun · bags.fm · bonk.fun</p>
      </div>
      <Card glow>
        <h2 style={{fontSize:19,fontWeight:800,marginBottom:22,textAlign:'center'}}>{isL?'Welcome back':'Create account'}</h2>
        {suc&&<div style={{background:'rgba(0,255,136,.08)',border:'1px solid rgba(0,255,136,.3)',borderRadius:'var(--radius)',padding:'12px 16px',marginBottom:16,fontSize:13,color:'var(--accent)'}}>✅ {suc}</div>}
        {err&&<div style={{background:'rgba(255,51,102,.08)',border:'1px solid rgba(255,51,102,.3)',borderRadius:'var(--radius)',padding:'12px 16px',marginBottom:16,fontSize:13,color:'var(--danger)'}}>❌ {err}</div>}
        <form onSubmit={submit} style={{display:'flex',flexDirection:'column',gap:14}}>
          <Field label="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required/>
          <Field label="Password" type="password" value={pw} onChange={e=>setPw(e.target.value)} placeholder={isL?'Your password':'8+ chars, uppercase, digit'} hint={!isL?'Encrypts your 12 wallets — keep it safe!':''} required/>
          <Btn type="submit" loading={loading} fullWidth size="lg" style={{marginTop:6}}>{isL?'→ Sign In':'→ Create Account & Generate 12 Wallets'}</Btn>
        </form>
        <div style={{textAlign:'center',marginTop:18,fontSize:13,color:'var(--text3)'}}>
          {isL?<>No account? <Link to="/register" style={{color:'var(--accent)',fontWeight:700}}>Register</Link></>:<>Have account? <Link to="/login" style={{color:'var(--accent)',fontWeight:700}}>Sign In</Link></>}
        </div>
        {!isL&&<div style={{marginTop:18,padding:14,background:'rgba(0,204,255,.05)',borderRadius:'var(--radius)',border:'1px solid rgba(0,204,255,.15)',fontSize:12,color:'var(--text2)',lineHeight:1.7}}>
          🔐 <strong style={{color:'var(--accent2)'}}>On register:</strong> 12 Solana wallets generated · Private keys encrypted with AES-256-GCM · Only you can decrypt (via password) · Export anytime
        </div>}
      </Card>
      <div style={{textAlign:'center',marginTop:16,fontSize:11,color:'var(--text3)'}}>5% platform fee after successful launches</div>
    </div>
  </div>
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard() {
  const {user}=useAuth(); const [s,setS]=useState(null)
  useEffect(()=>{api.get('/dashboard/stats').then(r=>setS(r.data)).catch(()=>{})},[])
  return <div>
    <div style={{marginBottom:28}}><h1 style={{fontSize:28,fontWeight:800,marginBottom:4}}>Dashboard</h1><p style={{color:'var(--text2)'}}>Welcome, <span style={{color:'var(--accent)'}}>{user?.email}</span></p></div>
    <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))',gap:14,marginBottom:24}}>
      {[{l:'Total Launches',v:s?.totalLaunches??0,a:'var(--accent2)'},{l:'Successful',v:s?.successfulLaunches??0,a:'var(--success)'},{l:'SOL Spent',v:fSol(s?.totalSolSpent),a:'var(--warn)'},{l:'Fees Owed',v:fSol(s?.feesUnpaid),a:s?.feesUnpaid>0?'var(--danger)':'var(--text2)'}].map(x=><Card key={x.l} style={{padding:18}}><Stat label={x.l} value={x.v} accent={x.a}/></Card>)}
    </div>
    {s?.feesUnpaid>0&&<div style={{background:'rgba(255,51,102,.06)',border:'1px solid rgba(255,51,102,.25)',borderRadius:'var(--radius-lg)',padding:18,marginBottom:20,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
      <div><strong style={{color:'var(--danger)'}}>⚠️ Outstanding fees:</strong> <span style={{color:'var(--text)'}}>{fSol(s.feesUnpaid)}</span></div>
      <Link to="/fees"><Btn variant="danger" size="sm">Pay Now</Btn></Link>
    </div>}
    <Card glow>
      <h3 style={{fontSize:14,fontWeight:700,color:'var(--text2)',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:14}}>Quick Actions</h3>
      <div style={{display:'flex',gap:10,flexWrap:'wrap'}}>
        <Link to="/bundler"><Btn>🚀 Launch Token</Btn></Link>
        <Link to="/wallets"><Btn variant="secondary">👛 View Wallets</Btn></Link>
        <Link to="/history"><Btn variant="ghost">📋 History</Btn></Link>
      </div>
    </Card>
  </div>
}

// ─── WALLETS ──────────────────────────────────────────────────────────────────
function Wallets() {
  const [ws,setWs]=useState([]); const [syncing,setSyncing]=useState(false); const [loading,setLoading]=useState(true)
  const [exportId,setExportId]=useState(null); const [exportAll,setExportAll]=useState(false)
  const [pw,setPw]=useState(''); const [expResult,setExpResult]=useState(null); const [expErr,setExpErr]=useState(''); const [expLoading,setExpLoading]=useState(false)
  const [total,setTotal]=useState(0)

  useEffect(()=>{api.get('/wallets').then(r=>setWs(r.data.wallets)).catch(()=>{}).finally(()=>setLoading(false))},[])

  const sync=async()=>{setSyncing(true);try{const r=await api.get('/wallets/balances');setWs(r.data.wallets);setTotal(r.data.totalSol||0);toast('Balances synced','success')}catch{toast('Sync failed','error')}finally{setSyncing(false)}}

  const doExport=async(id)=>{setExpLoading(true);setExpErr('')
    try{const r=id?await api.post(`/wallets/${id}/export`,{password:pw}):await api.post('/wallets/export-all',{password:pw});setExpResult(id?[r.data]:r.data.wallets)}catch(e){setExpErr(e.response?.data?.error||'Export failed')}finally{setExpLoading(false)}}

  const closeModal=()=>{setExportId(null);setExportAll(false);setPw('');setExpResult(null);setExpErr('')}

  if(loading) return <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:300}}><span style={{color:'var(--accent)',fontSize:24}}>⏳</span></div>

  return <div>
    <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
      <div><h1 style={{fontSize:28,fontWeight:800,marginBottom:4}}>Wallets</h1><p style={{color:'var(--text2)'}}>{ws.length} generated wallets</p></div>
      <div style={{display:'flex',gap:10}}>
        <Btn variant="ghost" size="sm" loading={syncing} onClick={sync}>🔄 Sync</Btn>
        <Btn variant="secondary" size="sm" onClick={()=>setExportAll(true)}>🔑 Export All</Btn>
      </div>
    </div>
    {total>0&&<Card style={{marginBottom:16,padding:'14px 20px',display:'flex',gap:28}}><Stat label="Total Balance" value={fSol(total)} accent="var(--accent)"/><Stat label="Wallets" value={ws.length}/></Card>}
    <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))',gap:12}}>
      {ws.map(w=><Card key={w.id} style={{padding:14}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:10}}>
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <div style={{width:26,height:26,borderRadius:8,background:'var(--bg3)',border:'1px solid var(--border2)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:800,color:'var(--accent)'}}>{w.wallet_index+1}</div>
            <span style={{fontWeight:700,fontSize:14}}>{w.label}</span>
          </div>
          <span style={{fontSize:13,fontWeight:700,fontFamily:'var(--font-mono)',color:w.sol_balance>0?'var(--accent)':'var(--text3)'}}>{fSol(w.sol_balance)}</span>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:6,background:'var(--bg3)',borderRadius:'var(--radius)',padding:'7px 10px'}}>
          <code style={{fontSize:11,color:'var(--text2)',flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',fontFamily:'var(--font-mono)'}}>{w.public_key}</code>
          <CopyBtn text={w.public_key}/>
        </div>
        <div style={{display:'flex',gap:6,marginTop:10}}>
          <a href={`https://solscan.io/account/${w.public_key}`} target="_blank" rel="noreferrer"><Btn variant="ghost" size="sm">🔗 Explorer</Btn></a>
          <Btn variant="ghost" size="sm" onClick={()=>setExportId(w.id)}>🔑 Export</Btn>
        </div>
      </Card>)}
    </div>
    {(exportId||exportAll)&&<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.75)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,backdropFilter:'blur(4px)'}}>
      <Card style={{width:'100%',maxWidth:480,position:'relative',maxHeight:'80vh',overflow:'auto'}}>
        <button onClick={closeModal} style={{position:'absolute',top:14,right:14,background:'none',border:'none',color:'var(--text3)',cursor:'pointer',fontSize:18}}>✕</button>
        <h3 style={{fontSize:18,fontWeight:800,marginBottom:4}}>🔑 Export Key{exportAll?'s':''}</h3>
        <p style={{color:'var(--danger)',fontSize:12,marginBottom:18}}>⚠️ Never share private keys. Store offline securely.</p>
        {!expResult?<>
          <Field label="Confirm Password" type="password" value={pw} onChange={e=>setPw(e.target.value)} error={expErr} containerStyle={{marginBottom:14}}/>
          <Btn variant="danger" fullWidth loading={expLoading} onClick={()=>doExport(exportAll?null:exportId)}>🔓 Decrypt & Export</Btn>
        </>:<div style={{display:'flex',flexDirection:'column',gap:10}}>
          {expResult.map((w,i)=><div key={i} style={{background:'var(--bg3)',borderRadius:'var(--radius)',padding:10,border:'1px solid var(--border2)'}}>
            <div style={{fontSize:11,color:'var(--text3)',marginBottom:4}}>Wallet {(w.index??i)+1}</div>
            <div style={{fontSize:11,color:'var(--text2)',marginBottom:4,fontFamily:'var(--font-mono)',wordBreak:'break-all'}}><strong>Pub:</strong> {w.publicKey}</div>
            <div style={{display:'flex',alignItems:'center',gap:6}}><code style={{fontSize:11,color:'var(--accent)',fontFamily:'var(--font-mono)',flex:1,wordBreak:'break-all'}}>{w.privateKey}</code><CopyBtn text={w.privateKey}/></div>
          </div>)}
          <p style={{fontSize:11,color:'var(--text3)'}}>Import into Phantom/Solflare using the base58 private key.</p>
        </div>}
      </Card>
    </div>}
  </div>
}

// ─── BUNDLER ──────────────────────────────────────────────────────────────────
function Bundler() {
  const [ws,setWs]=useState([]); const [step,setStep]=useState(1)
  const [lp,setLp]=useState('pump.fun'); const [name,setName]=useState(''); const [sym,setSym]=useState('')
  const [desc,setDesc]=useState(''); const [tw,setTw]=useState(''); const [tg,setTg]=useState(''); const [wb,setWb]=useState('')
  const [devSol,setDevSol]=useState('0.5'); const [solEach,setSolEach]=useState('0.1'); const [selW,setSelW]=useState([])
  const [pw,setPw]=useState(''); const [img,setImg]=useState(null); const [imgPrev,setImgPrev]=useState(null)
  const [loading,setLoading]=useState(false); const [result,setResult]=useState(null); const [err,setErr]=useState('')
  const [est,setEst]=useState(null); const imgRef=useRef()

  useEffect(()=>{api.get('/wallets').then(r=>setWs(r.data.wallets)).catch(()=>{})},[])

  const togW=idx=>setSelW(p=>p.includes(idx)?p.filter(x=>x!==idx):[...p,idx])

  useEffect(()=>{
    if(step===3&&selW.length&&solEach)
      api.post('/bundler/estimate',{walletIndices:selW,solPerWallet:solEach,devBuyAmountSol:devSol}).then(r=>setEst(r.data)).catch(()=>{})
  },[step,selW,solEach,devSol])

  const handleImg=e=>{const f=e.target.files[0];if(f){setImg(f);setImgPrev(URL.createObjectURL(f))}}

  const doLaunch=async()=>{
    setLoading(true);setErr('')
    try{
      const fd=new FormData()
      fd.append('password',pw);fd.append('launchpad',lp);fd.append('tokenName',name);fd.append('tokenSymbol',sym)
      fd.append('tokenDescription',desc);fd.append('twitter',tw);fd.append('telegram',tg);fd.append('website',wb)
      fd.append('devBuyAmountSol',devSol);fd.append('solPerWallet',solEach);fd.append('walletIndices',JSON.stringify(selW))
      if(img)fd.append('image',img)
      const r=await api.post('/bundler/launch',fd,{headers:{'Content-Type':'multipart/form-data'}})
      setResult(r.data);toast('🚀 Token launched!','success',6000)
    }catch(e){setErr(e.response?.data?.error||'Launch failed');toast('Launch failed','error')}
    finally{setLoading(false)}
  }

  const lps=[{id:'pump.fun',icon:'🟢',color:'#00ff88',desc:'Most popular'},{id:'bags.fm',icon:'💎',color:'#00ccff',desc:'Fee-share'},{id:'bonk.fun',icon:'🔥',color:'#ff6b35',desc:'Raydium LaunchLab'}]

  if(result) return <div style={{maxWidth:580,margin:'0 auto'}}>
    <div style={{textAlign:'center',marginBottom:28}}><div style={{fontSize:64,marginBottom:12}}>🚀</div><h1 style={{fontSize:26,fontWeight:800,color:'var(--accent)',marginBottom:6}}>Token Launched!</h1><p style={{color:'var(--text2)'}}>Live on {lp}</p></div>
    <Card glow style={{marginBottom:16}}>
      <div style={{fontSize:12,color:'var(--text3)',marginBottom:4}}>Token Mint</div>
      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}><code style={{fontFamily:'var(--font-mono)',fontSize:13,color:'var(--accent)',wordBreak:'break-all'}}>{result.mintAddress}</code><CopyBtn text={result.mintAddress}/></div>
      <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
        <a href={result.tokenUrl} target="_blank" rel="noreferrer"><Btn size="sm">🔗 View on {lp}</Btn></a>
        <a href={`https://solscan.io/token/${result.mintAddress}`} target="_blank" rel="noreferrer"><Btn variant="secondary" size="sm">🌐 Solscan</Btn></a>
      </div>
    </Card>
    <Card style={{marginBottom:16,background:'rgba(255,51,102,.05)',borderColor:'rgba(255,51,102,.2)'}}>
      <h3 style={{color:'var(--danger)',fontWeight:700,marginBottom:8}}>💸 Platform Fee Due</h3>
      <p style={{fontSize:14,color:'var(--text2)',marginBottom:10}}>5% of total spent = <strong style={{color:'var(--text)'}}>{fSol(result.feeOwed)}</strong></p>
      <Link to="/fees"><Btn variant="danger">Pay Fee Now</Btn></Link>
    </Card>
    <Btn variant="ghost" fullWidth onClick={()=>{setResult(null);setStep(1);setName('');setSym('');setSelW([]);setPw('')}}>Launch Another</Btn>
  </div>

  return <div>
    <div style={{marginBottom:24}}><h1 style={{fontSize:28,fontWeight:800,marginBottom:4}}>Bundle Launcher</h1><p style={{color:'var(--text2)'}}>Atomic multi-wallet token launch</p></div>

    {/* Steps */}
    <div style={{display:'flex',gap:0,marginBottom:28}}>
      {['Platform','Token','Wallets','Launch'].map((s,i)=><div key={s} style={{display:'flex',alignItems:'center',flex:1}}>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <div style={{width:26,height:26,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:800,background:step>i+1?'var(--accent)':step===i+1?'linear-gradient(135deg,var(--accent),var(--accent2))':'var(--surface2)',color:step>=i+1?'#000':'var(--text3)',border:step<i+1?'1px solid var(--border2)':'none'}}>{step>i+1?'✓':i+1}</div>
          <span style={{fontSize:13,fontWeight:step===i+1?700:400,color:step===i+1?'var(--text)':'var(--text3)'}}>{s}</span>
        </div>
        {i<3&&<div style={{flex:1,height:1,background:'var(--border)',margin:'0 8px'}}/>}
      </div>)}
    </div>

    {step===1&&<div>
      <h2 style={{fontSize:17,fontWeight:700,marginBottom:18}}>Choose Launchpad</h2>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))',gap:12,marginBottom:24}}>
        {lps.map(l=><div key={l.id} onClick={()=>setLp(l.id)} style={{padding:18,borderRadius:'var(--radius-lg)',cursor:'pointer',transition:'all .2s',border:`2px solid ${lp===l.id?l.color:'var(--border)'}`,background:lp===l.id?`rgba(128,128,128,.06)`:'var(--surface)',boxShadow:lp===l.id?`0 0 20px ${l.color}22`:undefined}}>
          <div style={{fontSize:28,marginBottom:8}}>{l.icon}</div>
          <div style={{fontWeight:800,fontSize:15,color:lp===l.id?l.color:'var(--text)',marginBottom:2}}>{l.id}</div>
          <div style={{fontSize:12,color:'var(--text3)'}}>{l.desc}</div>
        </div>)}
      </div>
      <Btn fullWidth onClick={()=>setStep(2)}>Next: Token Info →</Btn>
    </div>}

    {step===2&&<div>
      <h2 style={{fontSize:17,fontWeight:700,marginBottom:18}}>Token Information</h2>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginBottom:14}}>
        <Field label="Name *" value={name} onChange={e=>setName(e.target.value)} placeholder="My Token"/>
        <Field label="Symbol *" value={sym} onChange={e=>setSym(e.target.value.toUpperCase())} placeholder="MTK" maxLength={10}/>
      </div>
      <Field label="Description" value={desc} onChange={e=>setDesc(e.target.value)} placeholder="About your token..." containerStyle={{marginBottom:14}}/>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12,marginBottom:16}}>
        <Field label="Twitter" value={tw} onChange={e=>setTw(e.target.value)} placeholder="https://x.com/..."/>
        <Field label="Telegram" value={tg} onChange={e=>setTg(e.target.value)} placeholder="https://t.me/..."/>
        <Field label="Website" value={wb} onChange={e=>setWb(e.target.value)} placeholder="https://..."/>
      </div>
      <div style={{marginBottom:20}}>
        <label style={{fontSize:13,fontWeight:700,color:'var(--text2)',letterSpacing:'.05em',textTransform:'uppercase',display:'block',marginBottom:8}}>Token Logo</label>
        <div onClick={()=>imgRef.current?.click()} style={{border:`2px dashed ${imgPrev?'var(--accent)':'var(--border2)'}`,borderRadius:'var(--radius-lg)',padding:24,textAlign:'center',cursor:'pointer',transition:'all .2s'}}>
          {imgPrev?<img src={imgPrev} style={{width:70,height:70,borderRadius:10,objectFit:'cover',margin:'0 auto 6px'}} alt="preview"/>:<div style={{fontSize:28,marginBottom:6}}>🖼️</div>}
          <div style={{fontSize:12,color:'var(--text3)'}}>{imgPrev?'Click to change':'Click to upload logo (PNG, JPG, GIF)'}</div>
        </div>
        <input ref={imgRef} type="file" accept="image/*" onChange={handleImg} style={{display:'none'}}/>
      </div>
      <div style={{display:'flex',gap:10}}><Btn variant="ghost" onClick={()=>setStep(1)}>← Back</Btn><Btn fullWidth onClick={()=>setStep(3)} disabled={!name||!sym}>Next: Wallets →</Btn></div>
    </div>}

    {step===3&&<div>
      <h2 style={{fontSize:17,fontWeight:700,marginBottom:8}}>Configure Bundle</h2>
      <p style={{color:'var(--text2)',fontSize:13,marginBottom:18}}>Wallet 1 = creator/dev wallet. Select others for bundle buying.</p>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginBottom:20}}>
        <Field label="Dev Buy (SOL)" type="number" value={devSol} onChange={e=>setDevSol(e.target.value)} hint="Creator's initial purchase"/>
        <Field label="SOL Per Bundle Wallet" type="number" value={solEach} onChange={e=>setSolEach(e.target.value)} hint="Each selected wallet buys this amount"/>
      </div>
      <div style={{marginBottom:18}}>
        <div style={{fontSize:13,fontWeight:700,color:'var(--text2)',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:10}}>Select Bundle Wallets ({selW.length}/11)</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))',gap:8}}>
          {ws.slice(1).map(w=>{const on=selW.includes(w.wallet_index); return <div key={w.id} onClick={()=>togW(w.wallet_index)} style={{padding:'10px 12px',borderRadius:'var(--radius)',cursor:'pointer',transition:'all .2s',border:`1px solid ${on?'var(--accent)':'var(--border)'}`,background:on?'rgba(0,255,136,.05)':'var(--surface)',display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:18,height:18,borderRadius:4,border:`2px solid ${on?'var(--accent)':'var(--border2)'}`,background:on?'var(--accent)':'transparent',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>{on&&<span style={{color:'#000',fontSize:10,fontWeight:900}}>✓</span>}</div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontWeight:700,fontSize:13}}>Wallet {w.wallet_index+1}</div>
              <div style={{fontSize:11,color:'var(--text3)',fontFamily:'var(--font-mono)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{fAddr(w.public_key)}</div>
            </div>
            <span style={{fontSize:12,fontFamily:'var(--font-mono)',color:w.sol_balance>0?'var(--accent)':'var(--text3)',flexShrink:0}}>{fSol(w.sol_balance)}</span>
          </div>})}
        </div>
      </div>
      {ws[0]&&<div style={{background:'rgba(0,204,255,.05)',borderRadius:'var(--radius)',padding:'10px 14px',marginBottom:14,border:'1px solid rgba(0,204,255,.15)',fontSize:13}}>
        <strong style={{color:'var(--accent2)'}}>Creator (Wallet 1):</strong> <code style={{fontFamily:'var(--font-mono)',fontSize:11}}>{fAddr(ws[0].public_key,6)}</code> · {fSol(ws[0].sol_balance)}
      </div>}
      {est&&<Card style={{marginBottom:16,background:'var(--bg3)',padding:14}}>
        <div style={{fontSize:12,fontWeight:700,color:'var(--text2)',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:10}}>Cost Estimate</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
          <Stat label="Bundle Total" value={fSol(est.bundleTotal)}/>
          <Stat label="Dev Buy" value={fSol(est.devBuyAmountSol)}/>
          <Stat label="5% Fee" value={fSol(est.estimatedFee)} accent="var(--warn)"/>
        </div>
      </Card>}
      <div style={{display:'flex',gap:10}}><Btn variant="ghost" onClick={()=>setStep(2)}>← Back</Btn><Btn fullWidth onClick={()=>setStep(4)} disabled={!selW.length}>Next: Confirm →</Btn></div>
    </div>}

    {step===4&&<div>
      <h2 style={{fontSize:17,fontWeight:700,marginBottom:18}}>Confirm & Launch</h2>
      <Card style={{marginBottom:18}}>
        {[['Launchpad',`${LP_ICON[lp]} ${lp}`],['Token',`${name} (${sym})`],['Dev Buy',fSol(devSol)],['Bundle',`${selW.length} wallets × ${solEach} SOL`],['Total Bundle',fSol(selW.length*parseFloat(solEach))],['5% Fee',fSol(est?.estimatedFee||0)]].map(([k,v])=><div key={k} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:'1px solid var(--border)'}}>
          <span style={{fontSize:13,color:'var(--text3)'}}>{k}</span><span style={{fontWeight:700,fontSize:14}}>{v}</span>
        </div>)}
      </Card>
      <Field label="Password" type="password" value={pw} onChange={e=>setPw(e.target.value)} hint="Decrypts wallets to sign transactions" error={err} containerStyle={{marginBottom:14}}/>
      <div style={{background:'rgba(255,170,0,.06)',border:'1px solid rgba(255,170,0,.2)',borderRadius:'var(--radius)',padding:'10px 14px',marginBottom:16,fontSize:13,color:'var(--warn)'}}>
        ⚡ Transactions sent via Jito bundles for atomic execution. Ensure wallets have enough SOL.
      </div>
      <div style={{display:'flex',gap:10}}><Btn variant="ghost" onClick={()=>setStep(3)}>← Back</Btn><Btn fullWidth loading={loading} disabled={!pw} size="lg" onClick={doLaunch} style={{background:'linear-gradient(135deg,var(--accent),var(--accent2))',color:'#000'}}>🚀 Launch Token</Btn></div>
    </div>}
  </div>
}

// ─── HISTORY ─────────────────────────────────────────────────────────────────
function History() {
  const [ls,setLs]=useState([]); const [loading,setLoading]=useState(true); const [sel,setSel]=useState(null)
  useEffect(()=>{api.get('/bundler/launches').then(r=>setLs(r.data.launches)).catch(()=>{}).finally(()=>setLoading(false))},[])
  const badge=s=>({success:<span className="badge badge-success">✓ Success</span>,pending:<span className="badge badge-warn">⏳ Pending</span>,failed:<span className="badge badge-danger">✗ Failed</span>}[s]||<span className="badge badge-neutral">{s}</span>)
  if(loading) return <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:300}}><span style={{color:'var(--accent)',fontSize:24}}>⏳</span></div>
  return <div>
    <div style={{marginBottom:24}}><h1 style={{fontSize:28,fontWeight:800,marginBottom:4}}>Launch History</h1><p style={{color:'var(--text2)'}}>{ls.length} launches</p></div>
    {!ls.length?<Card style={{textAlign:'center',padding:48}}><div style={{fontSize:48,marginBottom:14}}>🚀</div><h3 style={{marginBottom:8}}>No launches yet</h3><Link to="/bundler"><Btn>Launch Now</Btn></Link></Card>:
    <div style={{display:'flex',flexDirection:'column',gap:10}}>
      {ls.map(l=><Card key={l.id} style={{padding:14,cursor:'pointer'}} onClick={()=>setSel(sel?.id===l.id?null:l)}>
        <div style={{display:'flex',alignItems:'center',gap:14}}>
          <span style={{fontSize:22}}>{LP_ICON[l.launchpad]||'🚀'}</span>
          <div style={{flex:1}}>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:2}}><span style={{fontWeight:800}}>{l.token_name}</span><span style={{color:'var(--text3)',fontSize:13}}>{l.token_symbol}</span>{badge(l.status)}{l.fee_paid?<span className="badge badge-success">Fee Paid</span>:l.fee_sol>0?<span className="badge badge-warn">Fee Owed</span>:null}</div>
            <div style={{display:'flex',gap:14,fontSize:12,color:'var(--text3)'}}><span>{fDate(l.created_at)}</span><span style={{color:LP_COLOR[l.launchpad]}}>{l.launchpad}</span><span>{fSol(l.initial_sol_spent)} dev</span><span>{l.wallet_count} wallets</span></div>
          </div>
          {l.token_url&&<a href={l.token_url} target="_blank" rel="noreferrer" onClick={e=>e.stopPropagation()}><Btn size="sm" variant="ghost">🔗 View</Btn></a>}
        </div>
        {sel?.id===l.id&&l.token_mint&&<div style={{marginTop:12,paddingTop:12,borderTop:'1px solid var(--border)'}}>
          <div style={{fontSize:11,color:'var(--text3)',marginBottom:3}}>Token Mint</div>
          <div style={{display:'flex',alignItems:'center',gap:6}}><code style={{fontFamily:'var(--font-mono)',fontSize:12,color:'var(--accent)'}}>{l.token_mint}</code><CopyBtn text={l.token_mint}/></div>
          {l.fee_sol>0&&!l.fee_paid&&<div style={{marginTop:10,fontSize:13}}><span style={{color:'var(--warn)'}}>Fee due: {fSol(l.fee_sol)} — </span><Link to="/fees" style={{color:'var(--accent)'}}>Pay</Link></div>}
        </div>}
      </Card>)}
    </div>}
  </div>
}

// ─── FEES ─────────────────────────────────────────────────────────────────────
function Fees() {
  const [pending,setPending]=useState([]); const [loading,setLoading]=useState(true)
  const [paying,setPaying]=useState(null); const [pw,setPw]=useState(''); const [payerW,setPayerW]=useState(0)
  const [payLoading,setPayLoading]=useState(false); const [payErr,setPayErr]=useState(''); const [payOk,setPayOk]=useState(null)
  const [ws,setWs]=useState([])
  useEffect(()=>{Promise.all([api.get('/fees/pending'),api.get('/wallets')]).then(([f,w])=>{setPending(f.data.launches);setWs(w.data.wallets)}).catch(()=>{}).finally(()=>setLoading(false))},[])
  const doPay=async(lid)=>{setPayLoading(true);setPayErr('')
    try{const r=await api.post(`/fees/pay/${lid}`,{password:pw,payerWalletIndex:payerW});setPayOk(r.data);setPending(p=>p.filter(x=>x.id!==lid));toast('Fee paid!','success')}catch(e){setPayErr(e.response?.data?.error||'Failed')}finally{setPayLoading(false)}}
  const close=()=>{setPaying(null);setPw('');setPayOk(null);setPayErr('')}
  if(loading) return <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:300}}><span style={{color:'var(--accent)',fontSize:24}}>⏳</span></div>
  return <div>
    <div style={{marginBottom:24}}><h1 style={{fontSize:28,fontWeight:800,marginBottom:4}}>Platform Fees</h1><p style={{color:'var(--text2)'}}>5% of SOL spent after each launch</p></div>
    <Card style={{marginBottom:20,background:'rgba(0,204,255,.04)',borderColor:'rgba(0,204,255,.15)'}}>
      <div style={{display:'flex',gap:14}}><span style={{fontSize:28,flexShrink:0}}>🛡️</span><div><h3 style={{fontWeight:700,marginBottom:6}}>How Fees Work</h3><p style={{fontSize:13,color:'var(--text2)',lineHeight:1.6}}>5% of total SOL spent (dev buy + all bundle wallet purchases) collected after successful launches. Pay directly from your wallets to our fee wallet on-chain.</p></div></div>
    </Card>
    {!pending.length?<Card style={{textAlign:'center',padding:48}}><div style={{fontSize:48,marginBottom:14}}>✅</div><h3 style={{marginBottom:8}}>All paid up!</h3><p style={{color:'var(--text2)'}}>No outstanding fees</p></Card>:
    <div>
      <h3 style={{fontWeight:700,marginBottom:14,color:'var(--warn)'}}>⚠️ Outstanding ({pending.length})</h3>
      {pending.map(l=><Card key={l.id} style={{marginBottom:12}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:14}}>
          <div><div style={{fontWeight:800,fontSize:16,marginBottom:2}}>{l.token_name} ({l.token_symbol})</div><div style={{fontSize:12,color:'var(--text3)'}}>{l.launchpad} · {fDate(l.created_at)}</div><div style={{fontSize:20,fontWeight:800,color:'var(--danger)',marginTop:6,fontFamily:'var(--font-mono)'}}>{fSol(l.fee_sol)}</div></div>
          <Btn variant="danger" onClick={()=>setPaying(l)}>Pay {fSol(l.fee_sol)}</Btn>
        </div>
      </Card>)}
    </div>}
    {paying&&<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.75)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,backdropFilter:'blur(4px)'}}>
      <Card style={{width:'100%',maxWidth:420,position:'relative'}}>
        <button onClick={close} style={{position:'absolute',top:14,right:14,background:'none',border:'none',color:'var(--text3)',cursor:'pointer',fontSize:18}}>✕</button>
        {payOk?<div style={{textAlign:'center',padding:20}}><div style={{fontSize:52,marginBottom:14}}>✅</div><h3 style={{fontSize:19,fontWeight:800,color:'var(--success)',marginBottom:6}}>Fee Paid!</h3><p style={{color:'var(--text2)',marginBottom:10}}>Amount: {fSol(payOk.amountPaid)}</p><div style={{fontSize:11,fontFamily:'var(--font-mono)',color:'var(--text3)',wordBreak:'break-all'}}>{payOk.signature}</div></div>:
        <><h3 style={{fontSize:18,fontWeight:800,marginBottom:4}}>Pay Platform Fee</h3>
        <p style={{color:'var(--text2)',fontSize:14,marginBottom:18}}>{paying.token_name} — <strong style={{color:'var(--danger)'}}>{fSol(paying.fee_sol)}</strong></p>
        <div style={{marginBottom:14}}>
          <label style={{fontSize:13,fontWeight:700,color:'var(--text2)',textTransform:'uppercase',letterSpacing:'.05em',display:'block',marginBottom:6}}>Pay From Wallet</label>
          <select value={payerW} onChange={e=>setPayerW(e.target.value)} style={{width:'100%',background:'var(--surface)',border:'1px solid var(--border2)',borderRadius:'var(--radius)',padding:'10px 12px',color:'var(--text)',fontSize:14,outline:'none'}}>
            {ws.map(w=><option key={w.id} value={w.wallet_index}>Wallet {w.wallet_index+1} — {fSol(w.sol_balance)} — {fAddr(w.public_key)}</option>)}
          </select>
        </div>
        <Field label="Confirm Password" type="password" value={pw} onChange={e=>setPw(e.target.value)} error={payErr} containerStyle={{marginBottom:14}}/>
        <Btn variant="danger" fullWidth loading={payLoading} disabled={!pw} onClick={()=>doPay(paying.id)}>✓ Confirm Payment</Btn></>}
      </Card>
    </div>}
  </div>
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function App() {
  return <AuthProvider>
    <BrowserRouter>
      <Routes>
        <Route path="/login"     element={<AuthPage mode="login"/>}/>
        <Route path="/register"  element={<AuthPage mode="register"/>}/>
        <Route path="/dashboard" element={<RequireAuth><Layout><Dashboard/></Layout></RequireAuth>}/>
        <Route path="/bundler"   element={<RequireAuth><Layout><Bundler/></Layout></RequireAuth>}/>
        <Route path="/wallets"   element={<RequireAuth><Layout><Wallets/></Layout></RequireAuth>}/>
        <Route path="/history"   element={<RequireAuth><Layout><History/></Layout></RequireAuth>}/>
        <Route path="/fees"      element={<RequireAuth><Layout><Fees/></Layout></RequireAuth>}/>
        <Route path="*"          element={<Navigate to="/login"/>}/>
      </Routes>
      <Toasts/>
    </BrowserRouter>
  </AuthProvider>
}
