import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { Zap, Mail, Lock, Eye, EyeOff } from 'lucide-react';

function AuthLayout({ children, title, subtitle }) {
  return (
    <div style={{
      minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center',
      padding:24, position:'relative', overflow:'hidden'
    }}>
      {/* Background grid */}
      <div style={{
        position:'fixed', inset:0, zIndex:0,
        backgroundImage:`linear-gradient(rgba(124,58,237,0.03) 1px, transparent 1px),
                         linear-gradient(90deg, rgba(124,58,237,0.03) 1px, transparent 1px)`,
        backgroundSize:'40px 40px'
      }} />
      {/* Glow */}
      <div style={{
        position:'fixed', top:'20%', left:'50%', transform:'translateX(-50%)',
        width:600, height:600, borderRadius:'50%',
        background:'radial-gradient(circle, rgba(124,58,237,0.08) 0%, transparent 70%)',
        pointerEvents:'none', zIndex:0
      }} />

      <div style={{ position:'relative', zIndex:1, width:'100%', maxWidth:420 }}>
        {/* Logo */}
        <div style={{ textAlign:'center', marginBottom:40 }}>
          <div style={{
            width:56, height:56, background:'var(--accent)', borderRadius:14,
            display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 16px',
            boxShadow:'0 0 40px rgba(124,58,237,0.5)'
          }}>
            <Zap size={26} color="#fff" />
          </div>
          <h1 style={{ fontFamily:'var(--font-mono)', fontSize:22, fontWeight:700, letterSpacing:'0.05em', marginBottom:6 }}>
            {title}
          </h1>
          <p style={{ color:'var(--text-3)', fontSize:14 }}>{subtitle}</p>
        </div>

        <div className="card" style={{ border:'1px solid var(--border-h)' }}>
          {children}
        </div>
      </div>
    </div>
  );
}

export function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const submit = async e => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout title="NEXUS BUNDLER" subtitle="Sign in to your account">
      <form onSubmit={submit} style={{ display:'flex', flexDirection:'column', gap:18 }}>
        <div className="input-group">
          <label className="input-label">Email</label>
          <div style={{ position:'relative' }}>
            <Mail size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-3)' }} />
            <input type="email" className="input" style={{ paddingLeft:36 }}
              placeholder="you@example.com" value={email}
              onChange={e => setEmail(e.target.value)} required />
          </div>
        </div>
        <div className="input-group">
          <label className="input-label">Password</label>
          <div style={{ position:'relative' }}>
            <Lock size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-3)' }} />
            <input type={showPw ? 'text' : 'password'} className="input" style={{ paddingLeft:36, paddingRight:40 }}
              placeholder="••••••••" value={password}
              onChange={e => setPassword(e.target.value)} required />
            <button type="button" onClick={() => setShowPw(!showPw)}
              style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'var(--text-3)' }}>
              {showPw ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>
          </div>
        </div>
        <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading} style={{ marginTop:4 }}>
          {loading ? <><div className="spinner" />Signing in...</> : 'Sign In'}
        </button>
        <p style={{ textAlign:'center', color:'var(--text-3)', fontSize:13 }}>
          No account?{' '}
          <Link to="/register" style={{ color:'var(--accent-h)', textDecoration:'none' }}>Create one</Link>
        </p>
      </form>
    </AuthLayout>
  );
}

export function RegisterPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const submit = async e => {
    e.preventDefault();
    if (password !== confirm) return toast.error('Passwords do not match');
    if (password.length < 8) return toast.error('Password must be at least 8 characters');
    setLoading(true);
    try {
      await register(email, password);
      toast.success('Account created! 12 wallets generated.');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.errors?.[0]?.msg || err.response?.data?.error || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout title="CREATE ACCOUNT" subtitle="Get 12 wallets instantly on signup">
      <form onSubmit={submit} style={{ display:'flex', flexDirection:'column', gap:18 }}>
        <div className="input-group">
          <label className="input-label">Email</label>
          <div style={{ position:'relative' }}>
            <Mail size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-3)' }} />
            <input type="email" className="input" style={{ paddingLeft:36 }}
              placeholder="you@example.com" value={email}
              onChange={e => setEmail(e.target.value)} required />
          </div>
        </div>
        <div className="input-group">
          <label className="input-label">Password</label>
          <div style={{ position:'relative' }}>
            <Lock size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-3)' }} />
            <input type={showPw ? 'text' : 'password'} className="input" style={{ paddingLeft:36 }}
              placeholder="Min 8 chars, uppercase, number" value={password}
              onChange={e => setPassword(e.target.value)} required />
          </div>
        </div>
        <div className="input-group">
          <label className="input-label">Confirm Password</label>
          <div style={{ position:'relative' }}>
            <Lock size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-3)' }} />
            <input type={showPw ? 'text' : 'password'} className="input" style={{ paddingLeft:36 }}
              placeholder="Repeat password" value={confirm}
              onChange={e => setConfirm(e.target.value)} required />
          </div>
        </div>
        <label style={{ display:'flex', alignItems:'flex-start', gap:8, cursor:'pointer' }}>
          <input type="checkbox" onChange={e => setShowPw(e.target.checked)} style={{ marginTop:2 }} />
          <span style={{ fontSize:12, color:'var(--text-3)' }}>Show passwords</span>
        </label>
        <div style={{ background:'rgba(124,58,237,0.08)', border:'1px solid rgba(124,58,237,0.2)', borderRadius:'var(--r)', padding:12 }}>
          <p style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--accent-h)', lineHeight:1.6 }}>
            ✓ 12 Solana wallets generated instantly<br/>
            ✓ Private keys encrypted with your password<br/>
            ✓ 5% fee on bundle profits
          </p>
        </div>
        <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading}>
          {loading ? <><div className="spinner" />Creating account...</> : 'Create Account'}
        </button>
        <p style={{ textAlign:'center', color:'var(--text-3)', fontSize:13 }}>
          Have an account?{' '}
          <Link to="/login" style={{ color:'var(--accent-h)', textDecoration:'none' }}>Sign in</Link>
        </p>
      </form>
    </AuthLayout>
  );
}
