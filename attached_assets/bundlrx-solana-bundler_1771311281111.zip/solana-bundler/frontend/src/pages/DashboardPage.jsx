import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../hooks/useAuth';
import { Rocket, Wallet, TrendingUp, DollarSign, ExternalLink, ChevronRight } from 'lucide-react';

const LAUNCHPAD_INFO = {
  pumpfun: { name: 'Pump.fun', color: 'var(--pump)', badge: 'badge-pump' },
  bagsfm:  { name: 'Bags.fm',  color: 'var(--bags)', badge: 'badge-bags' },
  bonkfun: { name: 'Bonk.fun', color: 'var(--bonk)', badge: 'badge-bonk' },
};

function StatCard({ icon: Icon, label, value, sub, accent }) {
  return (
    <div className="card" style={{ position:'relative', overflow:'hidden' }}>
      <div style={{
        position:'absolute', top:-20, right:-20, width:80, height:80, borderRadius:'50%',
        background:`radial-gradient(circle, ${accent}20 0%, transparent 70%)`
      }} />
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:12 }}>
        <div style={{
          width:36, height:36, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center',
          background:`${accent}15`, border:`1px solid ${accent}30`
        }}>
          <Icon size={16} color={accent} />
        </div>
        <span style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', letterSpacing:'0.1em', textTransform:'uppercase' }}>{label}</span>
      </div>
      <div style={{ fontFamily:'var(--font-mono)', fontSize:26, fontWeight:700, color:'var(--text)' }}>{value}</div>
      {sub && <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', marginTop:4 }}>{sub}</div>}
    </div>
  );
}

export default function DashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard/stats').then(r => {
      setStats(r.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const s = stats?.stats || {};

  return (
    <div className="fade-in">
      {/* Header */}
      <div style={{ marginBottom:32 }}>
        <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', letterSpacing:'0.1em', textTransform:'uppercase', marginBottom:8 }}>
          Welcome back
        </div>
        <h1 style={{ fontFamily:'var(--font-sans)', fontSize:28, fontWeight:800, marginBottom:8 }}>
          {user?.email?.split('@')[0]}
        </h1>
        <p style={{ color:'var(--text-2)', fontSize:14 }}>
          Manage your Solana token launches and bundled buys
        </p>
      </div>

      {/* Stats */}
      <div className="grid-3" style={{ marginBottom:28 }}>
        <StatCard icon={Rocket} label="Total Launches" value={loading ? '—' : s.totalLaunches || 0}
          sub={`${s.successfulLaunches || 0} successful`} accent="var(--accent-h)" />
        <StatCard icon={Wallet} label="Wallet Balance" value={loading ? '—' : `${(s.totalWalletSol || 0).toFixed(4)} SOL`}
          sub={`${s.walletCount || 12} wallets`} accent="var(--accent2)" />
        <StatCard icon={DollarSign} label="Fees Paid" value={loading ? '—' : `${(s.totalFeesPaid || 0).toFixed(4)} SOL`}
          sub="5% of bundle spend" accent="var(--accent3)" />
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 320px', gap:24 }}>
        {/* Recent launches */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">Recent Launches</span>
            <Link to="/history" className="btn btn-secondary btn-sm">View all</Link>
          </div>
          {loading ? (
            <div style={{ display:'flex', justifyContent:'center', padding:32 }}>
              <div className="spinner" style={{ color:'var(--accent)' }} />
            </div>
          ) : !stats?.recentLaunches?.length ? (
            <div style={{ textAlign:'center', padding:40 }}>
              <Rocket size={36} color="var(--text-3)" style={{ marginBottom:12 }} />
              <p style={{ color:'var(--text-3)', fontFamily:'var(--font-mono)', fontSize:13 }}>No launches yet</p>
              <Link to="/launch" className="btn btn-primary btn-sm" style={{ marginTop:16 }}>Launch Token</Link>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {stats.recentLaunches.map(launch => {
                const lp = LAUNCHPAD_INFO[launch.launchpad] || {};
                return (
                  <div key={launch.id} style={{
                    display:'flex', alignItems:'center', gap:12, padding:'12px 14px',
                    background:'var(--bg-input)', borderRadius:'var(--r)', border:'1px solid var(--border)'
                  }}>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:13, fontWeight:700, marginBottom:4 }}>
                        {launch.token_name} <span style={{ color:'var(--text-3)' }}>({launch.token_symbol})</span>
                      </div>
                      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                        <span className={`badge ${lp.badge || ''}`}>{lp.name || launch.launchpad}</span>
                        <span className={`badge ${launch.status === 'completed' ? 'badge-success' : launch.status === 'failed' ? 'badge-fail' : 'badge-pending'}`}>
                          {launch.status}
                        </span>
                      </div>
                    </div>
                    <div style={{ textAlign:'right', flexShrink:0 }}>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:12, color:'var(--text-2)' }}>
                        {(launch.bundle_sol_total || 0).toFixed(3)} SOL
                      </div>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>
                        {new Date(launch.created_at).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Quick actions */}
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <div className="card glow" style={{ borderColor:'rgba(124,58,237,0.3)' }}>
            <h3 style={{ fontFamily:'var(--font-mono)', fontSize:14, fontWeight:700, marginBottom:6 }}>LAUNCH TOKEN</h3>
            <p style={{ color:'var(--text-3)', fontSize:13, marginBottom:16 }}>
              Bundle buy on Pump.fun, Bags.fm, or Bonk.fun with up to 12 wallets simultaneously.
            </p>
            <Link to="/launch" className="btn btn-primary btn-full">
              <Rocket size={14} /> Start Launch
            </Link>
          </div>

          <div className="card">
            <h3 style={{ fontFamily:'var(--font-mono)', fontSize:13, fontWeight:700, marginBottom:12, color:'var(--text-2)' }}>SUPPORTED LAUNCHPADS</h3>
            {[
              { name:'Pump.fun', desc:'The original meme coin launchpad', cls:'badge-pump', url:'https://pump.fun' },
              { name:'Bags.fm',  desc:'Fee-share token launches', cls:'badge-bags', url:'https://bags.fm' },
              { name:'Bonk.fun', desc:'BONK ecosystem launchpad', cls:'badge-bonk', url:'https://bonk.fun' },
            ].map(lp => (
              <a key={lp.name} href={lp.url} target="_blank" rel="noopener noreferrer"
                style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 0', textDecoration:'none',
                  borderBottom:'1px solid var(--border)' }}>
                <span className={`badge ${lp.cls}`} style={{ minWidth:80, justifyContent:'center' }}>{lp.name}</span>
                <span style={{ flex:1, fontSize:12, color:'var(--text-3)' }}>{lp.desc}</span>
                <ExternalLink size={12} color="var(--text-3)" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
