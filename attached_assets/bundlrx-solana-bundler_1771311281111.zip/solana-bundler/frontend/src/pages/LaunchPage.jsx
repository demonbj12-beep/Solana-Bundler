import React, { useState, useEffect, useRef } from 'react';
import api from '../utils/api';
import { useToast } from '../hooks/useToast';
import {
  Rocket, Upload, ChevronDown, AlertTriangle, CheckCircle,
  ExternalLink, RefreshCw, Info, X, Zap, Lock
} from 'lucide-react';

const LAUNCHPADS = [
  { id:'pumpfun', name:'Pump.fun', color:'var(--pump)', desc:'Largest Solana meme launchpad', url:'https://pump.fun' },
  { id:'bagsfm',  name:'Bags.fm',  color:'var(--bags)', desc:'Fee-share token launches', url:'https://bags.fm' },
  { id:'bonkfun', name:'Bonk.fun', color:'var(--bonk)', desc:'BONK ecosystem launchpad', url:'https://bonk.fun' },
];

function LaunchpadCard({ lp, selected, onSelect }) {
  return (
    <div onClick={() => onSelect(lp.id)} style={{
      cursor:'pointer', padding:16, borderRadius:'var(--r)',
      border: `1px solid ${selected ? lp.color : 'var(--border)'}`,
      background: selected ? `${lp.color}12` : 'var(--bg-input)',
      transition:'all 0.15s', position:'relative', overflow:'hidden'
    }}>
      {selected && (
        <div style={{ position:'absolute', top:8, right:8 }}>
          <CheckCircle size={14} color={lp.color} />
        </div>
      )}
      <div style={{ fontFamily:'var(--font-mono)', fontSize:13, fontWeight:700,
        color: selected ? lp.color : 'var(--text)', marginBottom:4 }}>
        {lp.name}
      </div>
      <div style={{ fontSize:11, color:'var(--text-3)' }}>{lp.desc}</div>
    </div>
  );
}

function WalletAllocRow({ wallet, allocation, onChange }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:12, padding:'8px 12px',
      background:'var(--bg-input)', borderRadius:'var(--r)', border:'1px solid var(--border)'
    }}>
      <div style={{ width:6, height:6, borderRadius:'50%',
        background: wallet.sol_balance > 0 ? 'var(--green)' : 'var(--text-3)' }} />
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontFamily:'var(--font-mono)', fontSize:11, fontWeight:700, marginBottom:2 }}>
          W{wallet.wallet_index + 1} · {wallet.label}
        </div>
        <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>
          {wallet.sol_balance?.toFixed(4) || '0.0000'} SOL available
        </div>
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
        <input
          type="number" min="0" step="0.01"
          value={allocation}
          onChange={e => onChange(parseFloat(e.target.value) || 0)}
          placeholder="0"
          style={{
            width:80, padding:'4px 8px', background:'var(--bg)',
            border:`1px solid ${allocation > 0 ? 'var(--accent)' : 'var(--border)'}`,
            borderRadius:'var(--r)', color:'var(--text)',
            fontFamily:'var(--font-mono)', fontSize:12, outline:'none', textAlign:'right'
          }}
        />
        <span style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', minWidth:28 }}>SOL</span>
      </div>
    </div>
  );
}

export default function LaunchPage() {
  const toast = useToast();
  const imageRef = useRef();

  const [step, setStep] = useState(1); // 1=config, 2=wallets, 3=confirm, 4=done
  const [launchpad, setLaunchpad] = useState('pumpfun');
  const [wallets, setWallets] = useState([]);
  const [allocations, setAllocations] = useState({});
  const [loading, setLoading] = useState(false);
  const [walletsLoading, setWalletsLoading] = useState(true);
  const [simulation, setSimulation] = useState(null);
  const [password, setPassword] = useState('');
  const [result, setResult] = useState(null);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);

  const [form, setForm] = useState({
    tokenName:'', tokenSymbol:'', tokenDescription:'',
    twitter:'', telegram:'', website:'',
    devBuyAmountSol:'0.5', creatorWalletIndex:'0'
  });

  useEffect(() => {
    api.get('/wallets/balances').then(r => {
      setWallets(r.data.wallets || []);
      setWalletsLoading(false);
    }).catch(() => setWalletsLoading(false));
  }, []);

  const handleImage = e => {
    const f = e.target.files?.[0];
    if (!f) return;
    setImageFile(f);
    const reader = new FileReader();
    reader.onload = ev => setImagePreview(ev.target.result);
    reader.readAsDataURL(f);
  };

  const setAlloc = (idx, val) => setAllocations(a => ({ ...a, [idx]: val }));

  const bundleConfig = Object.entries(allocations)
    .filter(([, amt]) => amt > 0)
    .map(([idx, amt]) => ({ walletIndex: parseInt(idx), amount: amt }));

  const runSimulation = async () => {
    if (!form.tokenName || !form.tokenSymbol) return toast.error('Fill in token name and symbol');
    setLoading(true);
    try {
      const r = await api.post('/bundler/simulate', { launchpad, bundleConfig, devBuyAmountSol: parseFloat(form.devBuyAmountSol) });
      setSimulation(r.data);
      setStep(3);
    } catch {
      toast.error('Simulation failed');
    } finally {
      setLoading(false);
    }
  };

  const executeLaunch = async () => {
    if (!password) return toast.error('Enter your password to sign transactions');
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append('password', password);
      fd.append('launchpad', launchpad);
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      fd.append('bundleConfig', JSON.stringify(bundleConfig));
      if (imageFile) fd.append('image', imageFile);

      const r = await api.post('/launch/execute', fd, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setResult(r.data);
      setStep(4);
      toast.success('Bundle launched successfully!');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Launch failed');
    } finally {
      setLoading(false);
    }
  };

  const lp = LAUNCHPADS.find(l => l.id === launchpad);
  const totalBundleSol = bundleConfig.reduce((s, b) => s + b.amount, 0);

  if (step === 4 && result) {
    const lpUrl = { pumpfun:`https://pump.fun/${result.mintAddress}`, bagsfm:`https://bags.fm/${result.mintAddress}`, bonkfun:`https://bonk.fun/coin/${result.mintAddress}` };
    return (
      <div className="fade-in" style={{ maxWidth:600, margin:'0 auto' }}>
        <div className="card" style={{ textAlign:'center', padding:48, border:'1px solid var(--green)' }}>
          <div style={{ width:64, height:64, borderRadius:'50%', background:'rgba(16,185,129,0.15)',
            display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 24px',
            border:'1px solid var(--green)' }}>
            <CheckCircle size={32} color="var(--green)" />
          </div>
          <h2 style={{ fontFamily:'var(--font-mono)', fontSize:20, fontWeight:700, marginBottom:8 }}>LAUNCH SUCCESSFUL</h2>
          <p style={{ color:'var(--text-3)', fontSize:14, marginBottom:24 }}>
            Your token has been launched and bundled across {result.txCount} transactions.
          </p>
          <div style={{ background:'var(--bg-input)', borderRadius:'var(--r)', padding:16, marginBottom:24, border:'1px solid var(--border)' }}>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', marginBottom:4 }}>MINT ADDRESS</div>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:12, wordBreak:'break-all', color:'var(--accent-h)' }}>
              {result.mintAddress}
            </div>
          </div>
          <div style={{ display:'flex', gap:12 }}>
            <a href={lpUrl[launchpad]} target="_blank" rel="noopener noreferrer"
              className="btn btn-primary" style={{ flex:1 }}>
              <ExternalLink size={14} /> View on {lp?.name}
            </a>
            <button onClick={() => { setStep(1); setResult(null); setPassword(''); setAllocations({}); }}
              className="btn btn-secondary" style={{ flex:1 }}>
              New Launch
            </button>
          </div>
          {result.feeInfo?.estimatedFee > 0 && (
            <div style={{ marginTop:20, padding:12, background:'rgba(245,158,11,0.08)', borderRadius:'var(--r)', border:'1px solid rgba(245,158,11,0.2)' }}>
              <p style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--accent3)' }}>
                ⚠ Platform fee of {result.feeInfo.estimatedFee.toFixed(4)} SOL (5%) is due.{' '}
                <a href="/fees" style={{ color:'var(--accent3)' }}>Pay now →</a>
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div style={{ marginBottom:28 }}>
        <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', letterSpacing:'0.1em', textTransform:'uppercase', marginBottom:8 }}>
          Token Bundler
        </div>
        <h1 style={{ fontFamily:'var(--font-sans)', fontSize:26, fontWeight:800, marginBottom:6 }}>Launch & Bundle</h1>
        <p style={{ color:'var(--text-2)', fontSize:14 }}>Launch your token and bundle buy with up to 12 wallets in one transaction</p>
      </div>

      {/* Progress */}
      <div style={{ display:'flex', alignItems:'center', gap:0, marginBottom:32, background:'var(--bg-card)', borderRadius:'var(--r-lg)', padding:'12px 20px', border:'1px solid var(--border)' }}>
        {['Configure','Allocate Wallets','Review','Done'].map((s, i) => (
          <React.Fragment key={s}>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <div style={{
                width:24, height:24, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center',
                fontFamily:'var(--font-mono)', fontSize:10, fontWeight:700,
                background: step > i+1 ? 'var(--green)' : step === i+1 ? 'var(--accent)' : 'var(--bg-input)',
                border: `1px solid ${step >= i+1 ? (step > i+1 ? 'var(--green)' : 'var(--accent)') : 'var(--border)'}`,
                color: step >= i+1 ? '#fff' : 'var(--text-3)'
              }}>{step > i+1 ? '✓' : i+1}</div>
              <span style={{ fontFamily:'var(--font-mono)', fontSize:11, color: step === i+1 ? 'var(--text)' : 'var(--text-3)', display: window.innerWidth < 600 ? 'none' : 'inline' }}>{s}</span>
            </div>
            {i < 3 && <div style={{ flex:1, height:1, background: step > i+1 ? 'var(--green)' : 'var(--border)', margin:'0 12px' }} />}
          </React.Fragment>
        ))}
      </div>

      {/* STEP 1: Token Config */}
      {step === 1 && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 340px', gap:24 }}>
          <div style={{ display:'flex', flexDirection:'column', gap:20 }}>
            <div className="card">
              <div className="card-header"><span className="card-title">Select Launchpad</span></div>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:12 }}>
                {LAUNCHPADS.map(lp => (
                  <LaunchpadCard key={lp.id} lp={lp} selected={launchpad === lp.id} onSelect={setLaunchpad} />
                ))}
              </div>
            </div>

            <div className="card">
              <div className="card-header"><span className="card-title">Token Details</span></div>
              <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
                <div className="grid-2">
                  <div className="input-group">
                    <label className="input-label">Token Name *</label>
                    <input className="input" placeholder="My Token" value={form.tokenName}
                      onChange={e => setForm(f => ({ ...f, tokenName: e.target.value }))} />
                  </div>
                  <div className="input-group">
                    <label className="input-label">Symbol *</label>
                    <input className="input" placeholder="MTK" value={form.tokenSymbol}
                      onChange={e => setForm(f => ({ ...f, tokenSymbol: e.target.value.toUpperCase().slice(0,10) }))} />
                  </div>
                </div>
                <div className="input-group">
                  <label className="input-label">Description</label>
                  <textarea className="input" rows={3} placeholder="Tell the world about your token..."
                    value={form.tokenDescription}
                    onChange={e => setForm(f => ({ ...f, tokenDescription: e.target.value }))}
                    style={{ resize:'vertical' }} />
                </div>
                <div className="grid-3">
                  <div className="input-group">
                    <label className="input-label">Twitter</label>
                    <input className="input" placeholder="@handle" value={form.twitter}
                      onChange={e => setForm(f => ({ ...f, twitter: e.target.value }))} />
                  </div>
                  <div className="input-group">
                    <label className="input-label">Telegram</label>
                    <input className="input" placeholder="t.me/group" value={form.telegram}
                      onChange={e => setForm(f => ({ ...f, telegram: e.target.value }))} />
                  </div>
                  <div className="input-group">
                    <label className="input-label">Website</label>
                    <input className="input" placeholder="https://..." value={form.website}
                      onChange={e => setForm(f => ({ ...f, website: e.target.value }))} />
                  </div>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card-header"><span className="card-title">Token Image</span></div>
              <div
                onClick={() => imageRef.current?.click()}
                style={{
                  border:'2px dashed var(--border)', borderRadius:'var(--r)',
                  padding:32, textAlign:'center', cursor:'pointer', transition:'all 0.15s',
                  background: imagePreview ? 'transparent' : 'var(--bg-input)'
                }}
              >
                <input ref={imageRef} type="file" accept="image/*" onChange={handleImage} style={{ display:'none' }} />
                {imagePreview ? (
                  <div style={{ position:'relative', display:'inline-block' }}>
                    <img src={imagePreview} alt="preview" style={{ width:100, height:100, borderRadius:8, objectFit:'cover' }} />
                    <button onClick={e => { e.stopPropagation(); setImageFile(null); setImagePreview(null); }}
                      style={{ position:'absolute', top:-6, right:-6, background:'var(--red)', border:'none', borderRadius:'50%', width:20, height:20, cursor:'pointer', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center' }}>
                      <X size={10} />
                    </button>
                  </div>
                ) : (
                  <>
                    <Upload size={28} color="var(--text-3)" style={{ marginBottom:8 }} />
                    <p style={{ color:'var(--text-3)', fontSize:13 }}>Click to upload image</p>
                    <p style={{ color:'var(--text-3)', fontSize:11, marginTop:4 }}>PNG, JPG up to 5MB</p>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Dev buy config */}
          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div className="card">
              <div className="card-header"><span className="card-title">Dev Buy</span></div>
              <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
                <div className="input-group">
                  <label className="input-label">Creator Wallet</label>
                  <select className="input" value={form.creatorWalletIndex}
                    onChange={e => setForm(f => ({ ...f, creatorWalletIndex: e.target.value }))}>
                    {wallets.map(w => (
                      <option key={w.id} value={w.wallet_index}>
                        W{w.wallet_index + 1} · {w.label} ({(w.sol_balance||0).toFixed(4)} SOL)
                      </option>
                    ))}
                  </select>
                </div>
                <div className="input-group">
                  <label className="input-label">Dev Buy Amount (SOL)</label>
                  <input type="number" min="0" step="0.01" className="input"
                    value={form.devBuyAmountSol}
                    onChange={e => setForm(f => ({ ...f, devBuyAmountSol: e.target.value }))} />
                </div>
              </div>
            </div>

            <div className="card" style={{ background:'rgba(124,58,237,0.06)', border:'1px solid rgba(124,58,237,0.2)' }}>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--accent-h)', fontWeight:700, marginBottom:12, textTransform:'uppercase', letterSpacing:'0.1em' }}>
                <Zap size={12} style={{ display:'inline', marginRight:4 }} /> How It Works
              </div>
              <ul style={{ display:'flex', flexDirection:'column', gap:8 }}>
                {[
                  '1. Configure token metadata',
                  '2. Allocate SOL to bundle wallets',
                  '3. Review and confirm',
                  '4. All txns sent in one Jito bundle',
                  '5. Pay 5% fee after profits'
                ].map((t, i) => (
                  <li key={i} style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', listStyle:'none' }}>{t}</li>
                ))}
              </ul>
            </div>

            <button className="btn btn-primary btn-full btn-lg" onClick={() => setStep(2)}
              disabled={!form.tokenName || !form.tokenSymbol}>
              Next: Allocate Wallets <ChevronDown size={14} style={{ transform:'rotate(-90deg)' }} />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Wallet Allocations */}
      {step === 2 && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 300px', gap:24 }}>
          <div className="card">
            <div className="card-header">
              <span className="card-title">Allocate Bundle Wallets</span>
              <span style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)' }}>
                Set 0 to skip a wallet
              </span>
            </div>
            {walletsLoading ? (
              <div style={{ display:'flex', justifyContent:'center', padding:32 }}>
                <div className="spinner" style={{ color:'var(--accent)' }} />
              </div>
            ) : (
              <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                {wallets.map(w => (
                  <WalletAllocRow key={w.id} wallet={w}
                    allocation={allocations[w.wallet_index] || 0}
                    onChange={val => setAlloc(w.wallet_index, val)} />
                ))}
              </div>
            )}
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div className="card">
              <div className="card-header"><span className="card-title">Bundle Summary</span></div>
              <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
                {[
                  { label:'Launchpad', val: lp?.name },
                  { label:'Token', val: `${form.tokenName} (${form.tokenSymbol})` },
                  { label:'Dev Buy', val: `${form.devBuyAmountSol} SOL` },
                  { label:'Active Wallets', val: bundleConfig.length },
                  { label:'Total Bundle', val: `${totalBundleSol.toFixed(4)} SOL`, highlight:true },
                  { label:'Platform Fee (5%)', val: `~${(totalBundleSol*0.05).toFixed(4)} SOL`, dim:true },
                ].map(({ label, val, highlight, dim }) => (
                  <div key={label} style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                    <span style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)' }}>{label}</span>
                    <span style={{ fontFamily:'var(--font-mono)', fontSize:12, fontWeight:700,
                      color: highlight ? 'var(--accent-h)' : dim ? 'var(--text-3)' : 'var(--text)' }}>
                      {val}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <button className="btn btn-secondary btn-full" onClick={() => setStep(1)}>← Back</button>
            <button className="btn btn-primary btn-full btn-lg"
              onClick={runSimulation} disabled={loading || bundleConfig.length === 0}>
              {loading ? <><div className="spinner" />Simulating...</> : 'Review Bundle →'}
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Review & Execute */}
      {step === 3 && simulation && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 340px', gap:24 }}>
          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div className="card">
              <div className="card-header">
                <span className="card-title">Bundle Wallets</span>
                <span className={`badge ${simulation.canExecute ? 'badge-success' : 'badge-fail'}`}>
                  {simulation.canExecute ? 'Ready' : 'Insufficient Funds'}
                </span>
              </div>
              {simulation.bundleWallets.map((w, i) => (
                <div key={i} style={{
                  display:'flex', alignItems:'center', gap:12, padding:'10px 14px',
                  background:'var(--bg-input)', borderRadius:'var(--r)', border:`1px solid ${w.hasEnoughBalance ? 'var(--border)' : 'var(--red)'}`,
                  marginBottom:8
                }}>
                  <div style={{ width:6, height:6, borderRadius:'50%', flexShrink:0,
                    background: w.hasEnoughBalance ? 'var(--green)' : 'var(--red)' }} />
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:'var(--font-mono)', fontSize:12, fontWeight:700 }}>
                      W{w.wallet_index+1} · {w.label}
                    </div>
                    <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>
                      Balance: {w.sol_balance?.toFixed(4)} SOL · Buy: {w.allocatedSol} SOL
                    </div>
                  </div>
                  {!w.hasEnoughBalance && (
                    <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--red)' }}>
                      -{w.shortfall?.toFixed(4)} SOL
                    </div>
                  )}
                </div>
              ))}
              {simulation.warnings?.length > 0 && (
                <div style={{ padding:12, background:'rgba(239,68,68,0.08)', borderRadius:'var(--r)', border:'1px solid rgba(239,68,68,0.2)', marginTop:8 }}>
                  {simulation.warnings.map((w, i) => (
                    <p key={i} style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--red)' }}>
                      <AlertTriangle size={10} style={{ display:'inline', marginRight:4 }} />{w}
                    </p>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div className="card">
              <div className="card-header"><span className="card-title">Final Summary</span></div>
              <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                {[
                  { label:'Launchpad', val: lp?.name },
                  { label:'Token', val: `${form.tokenName} (${form.tokenSymbol})` },
                  { label:'Dev Buy', val: `${simulation.devBuyAmountSol} SOL` },
                  { label:'Bundle Wallets', val: simulation.bundleWallets.length },
                  { label:'Total Bundle SOL', val: `${simulation.totalBundleSol?.toFixed(4)} SOL` },
                  { label:'Platform Fee', val: `${simulation.platformFee?.toFixed(4)} SOL` },
                ].map(({ label, val }) => (
                  <div key={label} style={{ display:'flex', justifyContent:'space-between' }}>
                    <span style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)' }}>{label}</span>
                    <span style={{ fontFamily:'var(--font-mono)', fontSize:12, fontWeight:700 }}>{val}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="card" style={{ border:'1px solid var(--border-h)' }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12 }}>
                <Lock size={14} color="var(--accent-h)" />
                <span style={{ fontFamily:'var(--font-mono)', fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'0.1em' }}>
                  Sign Transactions
                </span>
              </div>
              <div className="input-group">
                <label className="input-label">Your Password</label>
                <input type="password" className="input" placeholder="Enter password to sign"
                  value={password} onChange={e => setPassword(e.target.value)} />
              </div>
              <p style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)', marginTop:8 }}>
                Used only to decrypt wallet keys locally. Never stored.
              </p>
            </div>

            <button className="btn btn-secondary btn-full" onClick={() => setStep(2)}>← Back</button>
            <button
              className="btn btn-primary btn-full btn-lg glow"
              onClick={executeLaunch}
              disabled={loading || !password || !simulation.canExecute}>
              {loading ? <><div className="spinner" />Launching...</> : <><Rocket size={16} /> EXECUTE BUNDLE</>}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
