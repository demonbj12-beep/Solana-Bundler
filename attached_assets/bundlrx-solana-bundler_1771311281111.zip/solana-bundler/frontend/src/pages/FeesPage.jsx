import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import { useToast } from '../hooks/useToast';
import { DollarSign, CheckCircle, AlertTriangle, ExternalLink, Lock } from 'lucide-react';

export default function FeesPage() {
  const toast = useToast();
  const [pending, setPending] = useState([]);
  const [history, setHistory] = useState([]);
  const [wallets, setWallets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [payModal, setPayModal] = useState(null);
  const [payPassword, setPayPassword] = useState('');
  const [payWallet, setPayWallet] = useState('0');
  const [paying, setPaying] = useState(false);
  const [feeWallet, setFeeWallet] = useState('');

  useEffect(() => {
    Promise.all([
      api.get('/fees/pending'),
      api.get('/fees/history'),
      api.get('/wallets')
    ]).then(([pend, hist, wall]) => {
      setPending(pend.data.pending || []);
      setFeeWallet(pend.data.feeWallet || '');
      setHistory(hist.data.fees || []);
      setWallets(wall.data.wallets || []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const payFee = async () => {
    if (!payPassword) return toast.error('Password required');
    setPaying(true);
    try {
      const r = await api.post('/fees/pay', {
        launchId: payModal.launch_id,
        payerWalletIndex: parseInt(payWallet),
        password: payPassword
      });
      toast.success(`Fee paid! TX: ${r.data.signature?.slice(0,12)}...`);
      setPending(p => p.filter(x => x.launch_id !== payModal.launch_id));
      setHistory(h => [{ ...payModal, amount_sol: r.data.feeAmount, tx_signature: r.data.signature, status:'confirmed' }, ...h]);
      setPayModal(null);
      setPayPassword('');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Fee payment failed');
    }
    setPaying(false);
  };

  const totalPending = pending.reduce((s, p) => s + (p.fee_owed || 0), 0);

  return (
    <div className="fade-in">
      <div style={{ marginBottom:28 }}>
        <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', letterSpacing:'0.1em', textTransform:'uppercase', marginBottom:8 }}>
          Platform Fees
        </div>
        <h1 style={{ fontFamily:'var(--font-sans)', fontSize:26, fontWeight:800, marginBottom:6 }}>Fees</h1>
        <p style={{ color:'var(--text-2)', fontSize:14 }}>
          5% platform fee on total bundle SOL spent, paid after launch
        </p>
      </div>

      {/* Fee info card */}
      <div className="card" style={{ marginBottom:24, background:'rgba(124,58,237,0.06)', border:'1px solid rgba(124,58,237,0.2)' }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:16 }}>
          <div>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', marginBottom:4, textTransform:'uppercase' }}>Total Pending Fees</div>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:28, fontWeight:700, color:'var(--accent-h)' }}>
              {totalPending.toFixed(4)} SOL
            </div>
          </div>
          <div style={{ textAlign:'right' }}>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', marginBottom:4 }}>Fee Rate</div>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:20, fontWeight:700 }}>5%</div>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>of bundle SOL spent</div>
          </div>
        </div>
        {feeWallet && (
          <div style={{ marginTop:16, paddingTop:16, borderTop:'1px solid rgba(124,58,237,0.2)' }}>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)', marginBottom:4 }}>Fee Wallet</div>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:12, color:'var(--accent-h)', wordBreak:'break-all' }}>{feeWallet}</div>
          </div>
        )}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:24 }}>
        {/* Pending fees */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">Pending Fees</span>
            <span className="badge badge-pending">{pending.length}</span>
          </div>
          {loading ? (
            <div style={{ display:'flex', justifyContent:'center', padding:32 }}><div className="spinner" style={{ color:'var(--accent)' }} /></div>
          ) : !pending.length ? (
            <div style={{ textAlign:'center', padding:32 }}>
              <CheckCircle size={28} color="var(--green)" style={{ marginBottom:10 }} />
              <p style={{ fontFamily:'var(--font-mono)', fontSize:12, color:'var(--text-3)' }}>All fees paid!</p>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {pending.map(p => (
                <div key={p.launch_id} style={{
                  padding:14, background:'var(--bg-input)', borderRadius:'var(--r)',
                  border:'1px solid rgba(245,158,11,0.2)'
                }}>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
                    <div>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:12, fontWeight:700 }}>
                        {p.token_name} ({p.token_symbol})
                      </div>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)', marginTop:2 }}>
                        Bundle: {(p.bundle_sol_total||0).toFixed(4)} SOL
                      </div>
                    </div>
                    <div style={{ textAlign:'right' }}>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:14, fontWeight:700, color:'var(--accent3)' }}>
                        {(p.fee_owed||0).toFixed(4)} SOL
                      </div>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>due</div>
                    </div>
                  </div>
                  <button className="btn btn-primary btn-sm btn-full"
                    onClick={() => { setPayModal(p); setPayPassword(''); }}>
                    <DollarSign size={12} /> Pay Fee
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Fee history */}
        <div className="card">
          <div className="card-header"><span className="card-title">Payment History</span></div>
          {!history.length ? (
            <p style={{ fontFamily:'var(--font-mono)', fontSize:12, color:'var(--text-3)', textAlign:'center', padding:32 }}>No payments yet</p>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {history.map((h, i) => (
                <div key={i} style={{
                  display:'flex', alignItems:'center', gap:12, padding:'10px 12px',
                  background:'var(--bg-input)', borderRadius:'var(--r)', border:'1px solid var(--border)'
                }}>
                  <CheckCircle size={14} color="var(--green)" />
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:'var(--font-mono)', fontSize:11, fontWeight:700 }}>
                      {h.token_name} ({h.token_symbol})
                    </div>
                    <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>
                      {new Date(h.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div style={{ fontFamily:'var(--font-mono)', fontSize:12, fontWeight:700, color:'var(--green)' }}>
                    {(h.amount_sol||0).toFixed(4)} SOL
                  </div>
                  {h.tx_signature && (
                    <a href={`https://solscan.io/tx/${h.tx_signature}`} target="_blank" rel="noopener noreferrer"
                      style={{ color:'var(--text-3)' }}>
                      <ExternalLink size={12} />
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Pay modal */}
      {payModal && (
        <div className="modal-overlay" onClick={() => setPayModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">Pay Platform Fee</div>
            <div style={{ background:'var(--bg-input)', borderRadius:'var(--r)', padding:14, marginBottom:20 }}>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', marginBottom:4 }}>Fee Amount</div>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:22, fontWeight:700, color:'var(--accent-h)' }}>
                {(payModal.fee_owed||0).toFixed(4)} SOL
              </div>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', marginTop:4 }}>
                For: {payModal.token_name} ({payModal.token_symbol})
              </div>
            </div>
            <div className="input-group" style={{ marginBottom:14 }}>
              <label className="input-label">Pay From Wallet</label>
              <select className="input" value={payWallet} onChange={e => setPayWallet(e.target.value)}>
                {wallets.map(w => (
                  <option key={w.id} value={w.wallet_index}>
                    W{w.wallet_index+1} · {w.label} ({(w.sol_balance||0).toFixed(4)} SOL)
                  </option>
                ))}
              </select>
            </div>
            <div className="input-group" style={{ marginBottom:20 }}>
              <label className="input-label"><Lock size={11} style={{ display:'inline', marginRight:4 }} />Password</label>
              <input type="password" className="input" placeholder="Confirm your password"
                value={payPassword} onChange={e => setPayPassword(e.target.value)} />
            </div>
            <div style={{ display:'flex', gap:10 }}>
              <button className="btn btn-secondary" style={{ flex:1 }} onClick={() => setPayModal(null)}>Cancel</button>
              <button className="btn btn-primary" style={{ flex:1 }} onClick={payFee} disabled={paying || !payPassword}>
                {paying ? <><div className="spinner" />Paying...</> : `Pay ${(payModal.fee_owed||0).toFixed(4)} SOL`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
