import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import { ExternalLink, RefreshCw, ChevronDown } from 'lucide-react';

const LP = {
  pumpfun: { name:'Pump.fun', cls:'badge-pump', url: m => `https://pump.fun/${m}` },
  bagsfm:  { name:'Bags.fm',  cls:'badge-bags', url: m => `https://bags.fm/${m}` },
  bonkfun: { name:'Bonk.fun', cls:'badge-bonk', url: m => `https://bonk.fun/coin/${m}` },
};

export default function HistoryPage() {
  const [launches, setLaunches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    api.get('/launch/history').then(r => {
      setLaunches(r.data.launches || []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  return (
    <div className="fade-in">
      <div style={{ marginBottom:28 }}>
        <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', letterSpacing:'0.1em', textTransform:'uppercase', marginBottom:8 }}>
          Launch History
        </div>
        <h1 style={{ fontFamily:'var(--font-sans)', fontSize:26, fontWeight:800 }}>All Launches</h1>
      </div>

      <div className="card">
        {loading ? (
          <div style={{ display:'flex', justifyContent:'center', padding:60 }}>
            <div className="spinner spinner-lg" style={{ color:'var(--accent)' }} />
          </div>
        ) : !launches.length ? (
          <div style={{ textAlign:'center', padding:60 }}>
            <p style={{ color:'var(--text-3)', fontFamily:'var(--font-mono)', fontSize:13 }}>No launches yet</p>
          </div>
        ) : (
          <div>
            {/* Table header */}
            <div style={{
              display:'grid', gridTemplateColumns:'1fr 100px 100px 100px 100px 80px',
              gap:12, padding:'8px 16px', marginBottom:8,
              fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)',
              textTransform:'uppercase', letterSpacing:'0.1em'
            }}>
              <span>Token</span><span>Launchpad</span><span>Status</span>
              <span>Dev Buy</span><span>Bundle</span><span>Date</span>
            </div>
            {launches.map(l => {
              const lp = LP[l.launchpad] || {};
              return (
                <div key={l.id}>
                  <div
                    onClick={() => setExpanded(expanded === l.id ? null : l.id)}
                    style={{
                      display:'grid', gridTemplateColumns:'1fr 100px 100px 100px 100px 80px',
                      gap:12, padding:'12px 16px', borderRadius:'var(--r)',
                      background: expanded === l.id ? 'var(--bg-input)' : 'transparent',
                      cursor:'pointer', transition:'background 0.15s', alignItems:'center',
                      borderBottom:'1px solid var(--border)'
                    }}
                  >
                    <div>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:13, fontWeight:700, marginBottom:2 }}>
                        {l.token_name}
                      </div>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>
                        {l.token_symbol} · {l.token_mint ? `${l.token_mint.slice(0,8)}...` : 'pending'}
                      </div>
                    </div>
                    <span className={`badge ${lp.cls || ''}`}>{lp.name || l.launchpad}</span>
                    <span className={`badge ${l.status==='completed'?'badge-success':l.status==='failed'?'badge-fail':'badge-pending'}`}>
                      {l.status}
                    </span>
                    <span style={{ fontFamily:'var(--font-mono)', fontSize:12 }}>
                      {(l.initial_sol_spent||0).toFixed(3)} SOL
                    </span>
                    <span style={{ fontFamily:'var(--font-mono)', fontSize:12 }}>
                      {(l.bundle_sol_total||0).toFixed(3)} SOL
                    </span>
                    <span style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>
                      {new Date(l.created_at).toLocaleDateString()}
                    </span>
                  </div>

                  {expanded === l.id && (
                    <div style={{
                      padding:'16px 16px', background:'var(--bg-input)',
                      borderBottom:'1px solid var(--border)',
                      display:'flex', gap:24, alignItems:'flex-start'
                    }}>
                      {l.token_mint && (
                        <div>
                          <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)', marginBottom:4, textTransform:'uppercase' }}>Mint</div>
                          <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--accent-h)' }}>{l.token_mint}</div>
                        </div>
                      )}
                      {l.tx_signature && (
                        <div>
                          <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)', marginBottom:4, textTransform:'uppercase' }}>TX</div>
                          <div style={{ fontFamily:'var(--font-mono)', fontSize:11 }}>{l.tx_signature.slice(0,16)}...</div>
                        </div>
                      )}
                      <div style={{ marginLeft:'auto', display:'flex', gap:8 }}>
                        {l.token_mint && (
                          <a href={lp.url?.(l.token_mint)} target="_blank" rel="noopener noreferrer"
                            className="btn btn-secondary btn-sm">
                            <ExternalLink size={12} /> {lp.name}
                          </a>
                        )}
                        {l.tx_signature && (
                          <a href={`https://solscan.io/tx/${l.tx_signature}`} target="_blank" rel="noopener noreferrer"
                            className="btn btn-secondary btn-sm">
                            Solscan ↗
                          </a>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
