import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import { useToast } from '../hooks/useToast';
import { RefreshCw, Download, Copy, Eye, EyeOff, Wallet, AlertTriangle, CheckCircle } from 'lucide-react';

function truncate(str, start = 6, end = 4) {
  if (!str) return '';
  if (str.length <= start + end) return str;
  return `${str.slice(0, start)}...${str.slice(-end)}`;
}

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <button onClick={copy} style={{ background:'none', border:'none', cursor:'pointer', color: copied ? 'var(--green)' : 'var(--text-3)', padding:2 }}>
      {copied ? <CheckCircle size={13} /> : <Copy size={13} />}
    </button>
  );
}

export default function WalletsPage() {
  const toast = useToast();
  const [wallets, setWallets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [exportModal, setExportModal] = useState(null); // 'single' | 'all'
  const [exportPassword, setExportPassword] = useState('');
  const [exportTarget, setExportTarget] = useState(null); // wallet id or null for all
  const [exportData, setExportData] = useState(null);
  const [exporting, setExporting] = useState(false);
  const [showKeys, setShowKeys] = useState({});

  const fetchWallets = async () => {
    try {
      const r = await api.get('/wallets');
      setWallets(r.data.wallets || []);
    } catch { toast.error('Failed to load wallets'); }
    setLoading(false);
  };

  const syncBalances = async () => {
    setSyncing(true);
    try {
      const r = await api.get('/wallets/balances');
      setWallets(r.data.wallets || []);
      toast.success('Balances synced');
    } catch { toast.error('Sync failed'); }
    setSyncing(false);
  };

  useEffect(() => { fetchWallets(); }, []);

  const openExportSingle = (id) => { setExportTarget(id); setExportModal('single'); setExportPassword(''); setExportData(null); };
  const openExportAll = () => { setExportTarget(null); setExportModal('all'); setExportPassword(''); setExportData(null); };

  const doExport = async () => {
    if (!exportPassword) return toast.error('Password required');
    setExporting(true);
    try {
      let r;
      if (exportTarget) {
        r = await api.post(`/wallets/${exportTarget}/export`, { password: exportPassword });
        setExportData([r.data]);
      } else {
        r = await api.post('/wallets/export-all', { password: exportPassword });
        setExportData(r.data.wallets);
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'Export failed');
    }
    setExporting(false);
  };

  const downloadJson = () => {
    if (!exportData) return;
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'nexus-wallets.json'; a.click();
    URL.revokeObjectURL(url);
  };

  const totalSol = wallets.reduce((s, w) => s + (w.sol_balance || 0), 0);

  return (
    <div className="fade-in">
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:28 }}>
        <div>
          <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', letterSpacing:'0.1em', textTransform:'uppercase', marginBottom:8 }}>
            Your Wallets
          </div>
          <h1 style={{ fontFamily:'var(--font-sans)', fontSize:26, fontWeight:800 }}>12 Wallets</h1>
        </div>
        <div style={{ display:'flex', gap:10 }}>
          <button className="btn btn-secondary" onClick={syncBalances} disabled={syncing}>
            <RefreshCw size={14} className={syncing ? 'spin' : ''} /> Sync Balances
          </button>
          <button className="btn btn-secondary" onClick={openExportAll}>
            <Download size={14} /> Export All
          </button>
        </div>
      </div>

      {/* Total balance bar */}
      <div className="card" style={{ marginBottom:20, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)', marginBottom:4, textTransform:'uppercase', letterSpacing:'0.1em' }}>Total Balance</div>
          <div style={{ fontFamily:'var(--font-mono)', fontSize:24, fontWeight:700, color:'var(--accent-h)' }}>
            {totalSol.toFixed(6)} SOL
          </div>
        </div>
        <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text-3)' }}>
          {wallets.filter(w => w.sol_balance > 0).length} / {wallets.length} funded
        </div>
      </div>

      {loading ? (
        <div style={{ display:'flex', justifyContent:'center', padding:60 }}>
          <div className="spinner spinner-lg" style={{ color:'var(--accent)' }} />
        </div>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(340px, 1fr))', gap:14 }}>
          {wallets.map(w => (
            <div key={w.id} className="card" style={{ padding:16 }}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
                <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <div style={{
                    width:32, height:32, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center',
                    background:'rgba(124,58,237,0.15)', border:'1px solid rgba(124,58,237,0.2)',
                    fontFamily:'var(--font-mono)', fontSize:11, fontWeight:700, color:'var(--accent-h)'
                  }}>W{w.wallet_index + 1}</div>
                  <div>
                    <div style={{ fontFamily:'var(--font-mono)', fontSize:12, fontWeight:700 }}>{w.label}</div>
                    <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>
                      {truncate(w.public_key, 8, 6)}
                      <span style={{ marginLeft:4 }}><CopyBtn text={w.public_key} /></span>
                    </div>
                  </div>
                </div>
                <div style={{ textAlign:'right' }}>
                  <div style={{ fontFamily:'var(--font-mono)', fontSize:14, fontWeight:700,
                    color: w.sol_balance > 0 ? 'var(--green)' : 'var(--text-3)' }}>
                    {(w.sol_balance || 0).toFixed(4)}
                  </div>
                  <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>SOL</div>
                </div>
              </div>
              <div style={{ display:'flex', gap:8 }}>
                <a href={`https://solscan.io/account/${w.public_key}`} target="_blank" rel="noopener noreferrer"
                  className="btn btn-secondary btn-sm" style={{ flex:1, fontSize:10 }}>
                  Solscan ↗
                </a>
                <button className="btn btn-secondary btn-sm" onClick={() => openExportSingle(w.id)}
                  style={{ flex:1, fontSize:10 }}>
                  <Download size={11} /> Export Key
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Export modal */}
      {exportModal && (
        <div className="modal-overlay" onClick={() => { setExportModal(null); setExportData(null); }}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">
              {exportTarget ? 'Export Wallet Key' : 'Export All Wallets'}
            </div>
            <div style={{ padding:12, background:'rgba(245,158,11,0.08)', border:'1px solid rgba(245,158,11,0.2)', borderRadius:'var(--r)', marginBottom:20 }}>
              <p style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--accent3)' }}>
                <AlertTriangle size={11} style={{ display:'inline', marginRight:4 }} />
                Never share private keys. Store them in a secure location only.
              </p>
            </div>

            {!exportData ? (
              <>
                <div className="input-group" style={{ marginBottom:20 }}>
                  <label className="input-label">Confirm Password</label>
                  <input type="password" className="input" placeholder="Enter your account password"
                    value={exportPassword} onChange={e => setExportPassword(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && doExport()} />
                </div>
                <div style={{ display:'flex', gap:10 }}>
                  <button className="btn btn-secondary" style={{ flex:1 }} onClick={() => setExportModal(null)}>Cancel</button>
                  <button className="btn btn-primary" style={{ flex:1 }} onClick={doExport} disabled={exporting || !exportPassword}>
                    {exporting ? <><div className="spinner" />Decrypting...</> : 'Reveal Keys'}
                  </button>
                </div>
              </>
            ) : (
              <>
                <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:20, maxHeight:300, overflowY:'auto' }}>
                  {exportData.map((d, i) => (
                    <div key={i} style={{ background:'var(--bg-input)', borderRadius:'var(--r)', padding:12, border:'1px solid var(--border)' }}>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)', marginBottom:4 }}>
                        {d.label || `W${(d.index||0)+1}`} — Public Key
                      </div>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:11, wordBreak:'break-all', marginBottom:8, display:'flex', alignItems:'center', gap:4 }}>
                        {d.publicKey} <CopyBtn text={d.publicKey} />
                      </div>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)', marginBottom:4 }}>Private Key</div>
                      <div style={{ fontFamily:'var(--font-mono)', fontSize:10, wordBreak:'break-all', color:'var(--accent-h)', display:'flex', alignItems:'center', gap:4 }}>
                        {showKeys[i] ? d.privateKey : '••••••••••••••••••••••••••••'}
                        <button onClick={() => setShowKeys(k => ({ ...k, [i]: !k[i] }))}
                          style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-3)', flexShrink:0 }}>
                          {showKeys[i] ? <EyeOff size={12} /> : <Eye size={12} />}
                        </button>
                        {showKeys[i] && <CopyBtn text={d.privateKey} />}
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{ display:'flex', gap:10 }}>
                  <button className="btn btn-secondary" style={{ flex:1 }} onClick={() => setExportModal(null)}>Close</button>
                  <button className="btn btn-primary" style={{ flex:1 }} onClick={downloadJson}>
                    <Download size={14} /> Download JSON
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
