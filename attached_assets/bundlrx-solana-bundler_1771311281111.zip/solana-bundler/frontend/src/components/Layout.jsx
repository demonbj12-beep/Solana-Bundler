import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import {
  LayoutDashboard, Rocket, Wallet, History, DollarSign,
  LogOut, Menu, X, Zap, ChevronRight
} from 'lucide-react';

const NAV = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/launch',    icon: Rocket,          label: 'Launch & Bundle' },
  { to: '/wallets',   icon: Wallet,          label: 'Wallets' },
  { to: '/history',   icon: History,         label: 'History' },
  { to: '/fees',      icon: DollarSign,      label: 'Fees' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div style={{ display:'flex', minHeight:'100vh' }}>
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          style={{
            position:'fixed', inset:0, background:'rgba(0,0,0,0.7)',
            zIndex:40, display:'none'
          }}
          className="mobile-overlay"
        />
      )}

      {/* Sidebar */}
      <aside style={{
        width: 240, background: 'var(--bg-card)', borderRight: '1px solid var(--border)',
        display:'flex', flexDirection:'column', position:'fixed', top:0, bottom:0, left:0,
        zIndex: 50, transition:'transform 0.25s ease',
      }}>
        {/* Logo */}
        <div style={{
          padding:'24px 20px', borderBottom:'1px solid var(--border)',
          display:'flex', alignItems:'center', gap:12
        }}>
          <div style={{
            width:36, height:36, background:'var(--accent)',
            borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center',
            boxShadow:'0 0 20px rgba(124,58,237,0.4)'
          }}>
            <Zap size={18} color="#fff" />
          </div>
          <div>
            <div style={{ fontFamily:'var(--font-mono)', fontWeight:700, fontSize:15, letterSpacing:'0.05em' }}>
              NEXUS
            </div>
            <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)', letterSpacing:'0.1em' }}>
              BUNDLER
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex:1, padding:'16px 12px', display:'flex', flexDirection:'column', gap:4 }}>
          {NAV.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              style={({ isActive }) => ({
                display:'flex', alignItems:'center', gap:12,
                padding:'10px 12px', borderRadius:'var(--r)',
                textDecoration:'none', transition:'all 0.15s',
                fontFamily:'var(--font-mono)', fontSize:12, fontWeight:700,
                letterSpacing:'0.05em', textTransform:'uppercase',
                background: isActive ? 'rgba(124,58,237,0.15)' : 'transparent',
                color: isActive ? 'var(--accent-h)' : 'var(--text-3)',
                borderLeft: isActive ? '2px solid var(--accent)' : '2px solid transparent',
              })}
            >
              <Icon size={16} />
              {label}
            </NavLink>
          ))}
        </nav>

        {/* User info */}
        <div style={{ padding:'16px 12px', borderTop:'1px solid var(--border)' }}>
          <div style={{
            display:'flex', alignItems:'center', gap:10,
            padding:'10px 12px', borderRadius:'var(--r)',
            background:'var(--bg-input)', marginBottom:8
          }}>
            <div style={{
              width:30, height:30, borderRadius:'50%',
              background:'linear-gradient(135deg, var(--accent), var(--accent2))',
              display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'var(--font-mono)', fontSize:12, fontWeight:700, color:'#fff',
              flexShrink:0
            }}>
              {user?.email?.[0]?.toUpperCase() || 'U'}
            </div>
            <div style={{ overflow:'hidden', flex:1 }}>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--text)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                {user?.email}
              </div>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-3)' }}>
                {user?.walletCount || 12} wallets
              </div>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="btn btn-secondary btn-full btn-sm"
            style={{ justifyContent:'flex-start', gap:8 }}
          >
            <LogOut size={14} /> Sign Out
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ marginLeft:240, flex:1, minHeight:'100vh', padding:'32px' }}>
        <Outlet />
      </main>
    </div>
  );
}
