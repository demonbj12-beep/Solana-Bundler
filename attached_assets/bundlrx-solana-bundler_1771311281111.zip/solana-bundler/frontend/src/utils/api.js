import axios from 'axios'
const api = axios.create({ baseURL: '/api', timeout: 60000 })
api.interceptors.request.use(c => { const t = localStorage.getItem('accessToken'); if(t) c.headers.Authorization=`Bearer ${t}`; return c })
api.interceptors.response.use(r=>r, async e => {
  const orig = e.config
  if(e.response?.status===401 && e.response?.data?.code==='TOKEN_EXPIRED' && !orig._retry){
    orig._retry=true
    try {
      const rt=localStorage.getItem('refreshToken')
      if(!rt){logout();return Promise.reject(e)}
      const {data}=await axios.post('/api/auth/refresh',{refreshToken:rt})
      localStorage.setItem('accessToken',data.accessToken)
      orig.headers.Authorization=`Bearer ${data.accessToken}`
      return api(orig)
    } catch { logout(); return Promise.reject(e) }
  }
  return Promise.reject(e)
})
function logout(){['accessToken','refreshToken','user'].forEach(k=>localStorage.removeItem(k));window.location.href='/login'}
export default api
