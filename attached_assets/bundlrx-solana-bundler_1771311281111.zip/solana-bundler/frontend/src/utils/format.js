export const formatSol = (n) => (n===null||n===undefined?'—':`${parseFloat(n).toFixed(4)} SOL`)
export const shortenAddr = (a,chars=4) => a?`${a.slice(0,chars)}...${a.slice(-chars)}`:''
export const formatDate = (d) => d?new Date(d).toLocaleString():'—'
export const launchpadColor = {
  'pump.fun':'#00ff88',
  'bags.fm':'#00ccff',
  'bonk.fun':'#ff6b35'
}
export const launchpadIcon = {
  'pump.fun':'🟢',
  'bags.fm':'💎',
  'bonk.fun':'🔥'
}
